import { createFileRoute, Link } from '@tanstack/react-router'
import { useMutation, useQuery } from '@tanstack/react-query'
import { useServerFn } from '@tanstack/react-start'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useState } from 'react'
import {
  createAdminAccountFn,
  createStudentAccountFn,
  listAdminAccountsFn,
  listStudentAccountsFn,
  deleteAdminAccountFn,
  deleteStudentAccountFn,
} from '@/server/functions/init-accounts'
import {
  ADMIN_ROLES,
  ROLE_LABELS,
  type AdminRole,
} from '@/server/functions/admin-auth'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  GraduationCap,
  ShieldCheck,
  UserPlus,
  Users,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Trash2,
  Copy,
  Key,
  RefreshCw,
  BookOpen,
  Eye,
  EyeOff,
} from 'lucide-react'

export const Route = createFileRoute('/_public/init-accounts')({
  component: InitAccountsPage,
})

// Admin form schema
const adminFormSchema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(8, 'Minimum 8 caractères'),
  firstName: z.string().min(1, 'Prénom requis'),
  lastName: z.string().min(1, 'Nom requis'),
  role: z.string().min(1, 'Rôle requis'),
  phone: z.string().optional(),
})

// Student form schema
const studentFormSchema = z.object({
  cne: z.string().min(1, 'CNE requis'),
  cin: z.string().min(1, 'CIN requis'),
  apogeeCode: z.string().min(1, 'Code Apogée requis'),
  firstName: z.string().min(1, 'Prénom requis'),
  lastName: z.string().min(1, 'Nom requis'),
  firstNameAr: z.string().optional(),
  lastNameAr: z.string().optional(),
  email: z.string().email('Email invalide').optional().or(z.literal('')),
  phone: z.string().optional(),
  gender: z.enum(['M', 'F']).optional(),
  status: z.string().default('active'),
})

function InitAccountsPage() {
  const [activeTab, setActiveTab] = useState('admins')
  const [showPassword, setShowPassword] = useState(false)
  const [lastCreatedAdmin, setLastCreatedAdmin] = useState<{
    email: string
    password: string
  } | null>(null)
  const [lastCreatedStudent, setLastCreatedStudent] = useState<{
    apogeeCode: string
    cin: string
  } | null>(null)

  // Server functions
  const createAdmin = useServerFn(createAdminAccountFn)
  const createStudent = useServerFn(createStudentAccountFn)
  const listAdmins = useServerFn(listAdminAccountsFn)
  const listStudents = useServerFn(listStudentAccountsFn)
  const deleteAdmin = useServerFn(deleteAdminAccountFn)
  const deleteStudent = useServerFn(deleteStudentAccountFn)

  // Queries
  const adminsQuery = useQuery({
    queryKey: ['init-admins'],
    queryFn: () => listAdmins(),
  })

  const studentsQuery = useQuery({
    queryKey: ['init-students'],
    queryFn: () => listStudents(),
  })

  // Admin form
  const adminForm = useForm({
    resolver: zodResolver(adminFormSchema),
    defaultValues: {
      email: '',
      password: '',
      firstName: '',
      lastName: '',
      role: 'admin',
      phone: '',
    },
  })

  // Student form
  const studentForm = useForm({
    resolver: zodResolver(studentFormSchema),
    defaultValues: {
      cne: '',
      cin: '',
      apogeeCode: '',
      firstName: '',
      lastName: '',
      firstNameAr: '',
      lastNameAr: '',
      email: '',
      phone: '',
      gender: undefined,
      status: 'active',
    },
  })

  // Mutations
  const createAdminMutation = useMutation({
    mutationFn: (data: z.infer<typeof adminFormSchema>) =>
      createAdmin({
        data: {
          ...data,
          role: data.role as AdminRole,
          phone: data.phone || null,
          departmentId: null,
        },
      }),
    onSuccess: (result) => {
      if (result.success && result.credentials) {
        setLastCreatedAdmin(result.credentials)
        adminForm.reset()
        void adminsQuery.refetch()
      }
    },
  })

  const createStudentMutation = useMutation({
    mutationFn: (data: z.infer<typeof studentFormSchema>) =>
      createStudent({
        data: {
          ...data,
          cin: data.cin,
          email: data.email || null,
          phone: data.phone || null,
          firstNameAr: data.firstNameAr || null,
          lastNameAr: data.lastNameAr || null,
          gender: data.gender || null,
        },
      }),
    onSuccess: (result) => {
      if (result.success && result.credentials) {
        setLastCreatedStudent({
          apogeeCode: result.credentials.apogeeCode,
          cin: result.credentials.cin,
        })
        studentForm.reset()
        void studentsQuery.refetch()
      }
    },
  })

  const deleteAdminMutation = useMutation({
    mutationFn: (id: string) => deleteAdmin({ data: { id } }),
    onSuccess: () => {
      void adminsQuery.refetch()
    },
  })

  const deleteStudentMutation = useMutation({
    mutationFn: (id: string) => deleteStudent({ data: { id } }),
    onSuccess: () => {
      void studentsQuery.refetch()
    },
  })

  const copyToClipboard = (text: string) => {
    void navigator.clipboard.writeText(text)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Decorative background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 mb-4 shadow-lg shadow-amber-500/25">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Panneau d'Initialisation des Comptes
          </h1>
          <p className="text-slate-400 max-w-xl mx-auto">
            Créez les comptes administrateurs et étudiants pour initialiser la
            plateforme UNIV-SCOLAR. Ce panneau est temporaire et sera supprimé
            après la configuration initiale.
          </p>
        </div>

        {/* Warning Banner */}
        <Alert className="mb-6 bg-amber-500/10 border-amber-500/30 text-amber-200">
          <AlertCircle className="h-4 w-4 text-amber-400" />
          <AlertTitle className="text-amber-300">Panneau Temporaire</AlertTitle>
          <AlertDescription className="text-amber-200/80">
            Ce panneau est destiné à l'initialisation du système uniquement.
            Supprimez cette page après avoir créé les comptes nécessaires.
          </AlertDescription>
        </Alert>

        {/* Main Tabs */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 p-1">
            <TabsTrigger
              value="admins"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              Administrateurs
            </TabsTrigger>
            <TabsTrigger
              value="students"
              className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              Étudiants
            </TabsTrigger>
          </TabsList>

          {/* ADMIN TAB */}
          <TabsContent value="admins" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Create Admin Form */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <UserPlus className="w-5 h-5 text-blue-400" />
                    Créer un Administrateur
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    Créez un compte administrateur avec accès au système
                    d'authentification.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form
                    onSubmit={adminForm.handleSubmit((data) =>
                      createAdminMutation.mutate(data),
                    )}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="admin-firstName"
                          className="text-slate-300"
                        >
                          Prénom *
                        </Label>
                        <Input
                          id="admin-firstName"
                          {...adminForm.register('firstName')}
                          placeholder="Ahmed"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                        {adminForm.formState.errors.firstName && (
                          <p className="text-xs text-red-400">
                            {adminForm.formState.errors.firstName.message}
                          </p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="admin-lastName"
                          className="text-slate-300"
                        >
                          Nom *
                        </Label>
                        <Input
                          id="admin-lastName"
                          {...adminForm.register('lastName')}
                          placeholder="Benali"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                        {adminForm.formState.errors.lastName && (
                          <p className="text-xs text-red-400">
                            {adminForm.formState.errors.lastName.message}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="admin-email" className="text-slate-300">
                        Email *
                      </Label>
                      <Input
                        id="admin-email"
                        type="email"
                        {...adminForm.register('email')}
                        placeholder="admin@universite.ma"
                        className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                      />
                      {adminForm.formState.errors.email && (
                        <p className="text-xs text-red-400">
                          {adminForm.formState.errors.email.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label
                        htmlFor="admin-password"
                        className="text-slate-300"
                      >
                        Mot de passe *
                      </Label>
                      <div className="relative">
                        <Input
                          id="admin-password"
                          type={showPassword ? 'text' : 'password'}
                          {...adminForm.register('password')}
                          placeholder="Minimum 8 caractères"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                      {adminForm.formState.errors.password && (
                        <p className="text-xs text-red-400">
                          {adminForm.formState.errors.password.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="admin-role" className="text-slate-300">
                        Rôle *
                      </Label>
                      <Select
                        value={adminForm.watch('role')}
                        onValueChange={(value) =>
                          adminForm.setValue('role', value)
                        }
                      >
                        <SelectTrigger className="bg-slate-900/50 border-slate-600 text-white">
                          <SelectValue placeholder="Sélectionner un rôle" />
                        </SelectTrigger>
                        <SelectContent>
                          {ADMIN_ROLES.map((role) => (
                            <SelectItem key={role} value={role}>
                              {ROLE_LABELS[role]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="admin-phone" className="text-slate-300">
                        Téléphone (optionnel)
                      </Label>
                      <Input
                        id="admin-phone"
                        {...adminForm.register('phone')}
                        placeholder="+212 6XX XXX XXX"
                        className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={createAdminMutation.isPending}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {createAdminMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Création en cours...
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-4 h-4 mr-2" />
                          Créer l'Administrateur
                        </>
                      )}
                    </Button>
                  </form>

                  {/* Success/Error Messages */}
                  {createAdminMutation.isSuccess &&
                    createAdminMutation.data?.success && (
                      <Alert className="mt-4 bg-green-500/10 border-green-500/30">
                        <CheckCircle2 className="h-4 w-4 text-green-400" />
                        <AlertTitle className="text-green-300">
                          Succès !
                        </AlertTitle>
                        <AlertDescription className="text-green-200/80">
                          {createAdminMutation.data.message}
                        </AlertDescription>
                      </Alert>
                    )}

                  {createAdminMutation.isSuccess &&
                    !createAdminMutation.data?.success && (
                      <Alert className="mt-4 bg-red-500/10 border-red-500/30">
                        <AlertCircle className="h-4 w-4 text-red-400" />
                        <AlertTitle className="text-red-300">Erreur</AlertTitle>
                        <AlertDescription className="text-red-200/80">
                          {createAdminMutation.data?.message}
                        </AlertDescription>
                      </Alert>
                    )}

                  {/* Last Created Credentials */}
                  {lastCreatedAdmin && (
                    <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                      <div className="flex items-center gap-2 mb-3">
                        <Key className="w-4 h-4 text-blue-400" />
                        <span className="font-medium text-blue-300">
                          Identifiants créés
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Email:</span>
                          <div className="flex items-center gap-2">
                            <code className="text-blue-200">
                              {lastCreatedAdmin.email}
                            </code>
                            <button
                              onClick={() =>
                                copyToClipboard(lastCreatedAdmin.email)
                              }
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Mot de passe:</span>
                          <div className="flex items-center gap-2">
                            <code className="text-blue-200">
                              {lastCreatedAdmin.password}
                            </code>
                            <button
                              onClick={() =>
                                copyToClipboard(lastCreatedAdmin.password)
                              }
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Admin List */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Users className="w-5 h-5 text-blue-400" />
                      Administrateurs Existants
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => adminsQuery.refetch()}
                      className="text-slate-400 hover:text-white"
                    >
                      <RefreshCw
                        className={`w-4 h-4 ${adminsQuery.isLoading ? 'animate-spin' : ''}`}
                      />
                    </Button>
                  </div>
                  <CardDescription className="text-slate-400">
                    {adminsQuery.data?.total || 0} compte(s) administrateur(s)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {adminsQuery.isLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-blue-400" />
                    </div>
                  ) : adminsQuery.data?.admins &&
                    adminsQuery.data.admins.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {adminsQuery.data.admins.map((admin) => (
                        <div
                          key={admin.id}
                          className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-700"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-white truncate">
                              {admin.firstName} {admin.lastName}
                            </p>
                            <p className="text-sm text-slate-400 truncate">
                              {admin.email}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge
                                variant="outline"
                                className="text-xs border-blue-500/50 text-blue-300"
                              >
                                {ROLE_LABELS[admin.role as AdminRole] ||
                                  admin.role}
                              </Badge>
                              <Badge
                                variant="outline"
                                className={`text-xs ${
                                  admin.isActive
                                    ? 'border-green-500/50 text-green-300'
                                    : 'border-red-500/50 text-red-300'
                                }`}
                              >
                                {admin.isActive ? 'Actif' : 'Inactif'}
                              </Badge>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteAdminMutation.mutate(admin.id)}
                            disabled={deleteAdminMutation.isPending}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-400">
                      <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Aucun administrateur créé</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* STUDENT TAB */}
          <TabsContent value="students" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Create Student Form */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <UserPlus className="w-5 h-5 text-emerald-400" />
                    Créer un Étudiant
                  </CardTitle>
                  <CardDescription className="text-slate-400">
                    Créez un compte étudiant. L'étudiant se connectera avec son
                    Code Apogée et CIN.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form
                    onSubmit={studentForm.handleSubmit((data) =>
                      createStudentMutation.mutate(data),
                    )}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-firstName"
                          className="text-slate-300"
                        >
                          Prénom *
                        </Label>
                        <Input
                          id="student-firstName"
                          {...studentForm.register('firstName')}
                          placeholder="Fatima"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-lastName"
                          className="text-slate-300"
                        >
                          Nom *
                        </Label>
                        <Input
                          id="student-lastName"
                          {...studentForm.register('lastName')}
                          placeholder="El Amrani"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-firstNameAr"
                          className="text-slate-300"
                        >
                          الاسم الشخصي
                        </Label>
                        <Input
                          id="student-firstNameAr"
                          {...studentForm.register('firstNameAr')}
                          placeholder="فاطمة"
                          dir="rtl"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-lastNameAr"
                          className="text-slate-300"
                        >
                          الاسم العائلي
                        </Label>
                        <Input
                          id="student-lastNameAr"
                          {...studentForm.register('lastNameAr')}
                          placeholder="العمراني"
                          dir="rtl"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                    </div>

                    <Separator className="bg-slate-700" />

                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="student-cne" className="text-slate-300">
                          CNE *
                        </Label>
                        <Input
                          id="student-cne"
                          {...studentForm.register('cne')}
                          placeholder="R123456789"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="student-cin" className="text-slate-300">
                          CIN *
                        </Label>
                        <Input
                          id="student-cin"
                          {...studentForm.register('cin')}
                          placeholder="AB123456"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500 uppercase"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-apogee"
                          className="text-slate-300"
                        >
                          Code Apogée *
                        </Label>
                        <Input
                          id="student-apogee"
                          {...studentForm.register('apogeeCode')}
                          placeholder="12345678"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-email"
                          className="text-slate-300"
                        >
                          Email (optionnel)
                        </Label>
                        <Input
                          id="student-email"
                          type="email"
                          {...studentForm.register('email')}
                          placeholder="etudiant@email.com"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-phone"
                          className="text-slate-300"
                        >
                          Téléphone (optionnel)
                        </Label>
                        <Input
                          id="student-phone"
                          {...studentForm.register('phone')}
                          placeholder="+212 6XX XXX XXX"
                          className="bg-slate-900/50 border-slate-600 text-white placeholder:text-slate-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-gender"
                          className="text-slate-300"
                        >
                          Genre
                        </Label>
                        <Select
                          value={studentForm.watch('gender')}
                          onValueChange={(value) =>
                            studentForm.setValue('gender', value as 'M' | 'F')
                          }
                        >
                          <SelectTrigger className="bg-slate-900/50 border-slate-600 text-white">
                            <SelectValue placeholder="Sélectionner" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="M">Masculin</SelectItem>
                            <SelectItem value="F">Féminin</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label
                          htmlFor="student-status"
                          className="text-slate-300"
                        >
                          Statut
                        </Label>
                        <Select
                          value={studentForm.watch('status')}
                          onValueChange={(value) =>
                            studentForm.setValue('status', value)
                          }
                        >
                          <SelectTrigger className="bg-slate-900/50 border-slate-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Actif</SelectItem>
                            <SelectItem value="inactive">Inactif</SelectItem>
                            <SelectItem value="suspended">Suspendu</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={createStudentMutation.isPending}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      {createStudentMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Création en cours...
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-4 h-4 mr-2" />
                          Créer l'Étudiant
                        </>
                      )}
                    </Button>
                  </form>

                  {/* Success/Error Messages */}
                  {createStudentMutation.isSuccess &&
                    createStudentMutation.data?.success && (
                      <Alert className="mt-4 bg-green-500/10 border-green-500/30">
                        <CheckCircle2 className="h-4 w-4 text-green-400" />
                        <AlertTitle className="text-green-300">
                          Succès !
                        </AlertTitle>
                        <AlertDescription className="text-green-200/80">
                          {createStudentMutation.data.message}
                        </AlertDescription>
                      </Alert>
                    )}

                  {createStudentMutation.isSuccess &&
                    !createStudentMutation.data?.success && (
                      <Alert className="mt-4 bg-red-500/10 border-red-500/30">
                        <AlertCircle className="h-4 w-4 text-red-400" />
                        <AlertTitle className="text-red-300">Erreur</AlertTitle>
                        <AlertDescription className="text-red-200/80">
                          {createStudentMutation.data?.message}
                        </AlertDescription>
                      </Alert>
                    )}

                  {/* Last Created Credentials */}
                  {lastCreatedStudent && (
                    <div className="mt-4 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg">
                      <div className="flex items-center gap-2 mb-3">
                        <Key className="w-4 h-4 text-emerald-400" />
                        <span className="font-medium text-emerald-300">
                          Identifiants de connexion
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Code Apogée:</span>
                          <div className="flex items-center gap-2">
                            <code className="text-emerald-200">
                              {lastCreatedStudent.apogeeCode}
                            </code>
                            <button
                              onClick={() =>
                                copyToClipboard(lastCreatedStudent.apogeeCode)
                              }
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">CIN:</span>
                          <div className="flex items-center gap-2">
                            <code className="text-emerald-200">
                              {lastCreatedStudent.cin}
                            </code>
                            <button
                              onClick={() =>
                                copyToClipboard(lastCreatedStudent.cin)
                              }
                              className="text-slate-400 hover:text-white"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-slate-400 mt-3">
                        L'étudiant utilise son Code Apogée et CIN pour se
                        connecter.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Student List */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                      <BookOpen className="w-5 h-5 text-emerald-400" />
                      Étudiants Existants
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => studentsQuery.refetch()}
                      className="text-slate-400 hover:text-white"
                    >
                      <RefreshCw
                        className={`w-4 h-4 ${studentsQuery.isLoading ? 'animate-spin' : ''}`}
                      />
                    </Button>
                  </div>
                  <CardDescription className="text-slate-400">
                    {studentsQuery.data?.total || 0} compte(s) étudiant(s)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {studentsQuery.isLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 animate-spin text-emerald-400" />
                    </div>
                  ) : studentsQuery.data?.students &&
                    studentsQuery.data.students.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {studentsQuery.data.students.map((student) => (
                        <div
                          key={student.id}
                          className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-700"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-white truncate">
                              {student.firstName} {student.lastName}
                            </p>
                            <div className="flex items-center gap-3 text-sm text-slate-400 mt-1">
                              <span>CNE: {student.cne}</span>
                              <span>•</span>
                              <span>Apogée: {student.apogeeCode}</span>
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge
                                variant="outline"
                                className={`text-xs ${
                                  student.status === 'active'
                                    ? 'border-green-500/50 text-green-300'
                                    : 'border-amber-500/50 text-amber-300'
                                }`}
                              >
                                {student.status || 'active'}
                              </Badge>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              deleteStudentMutation.mutate(student.id)
                            }
                            disabled={deleteStudentMutation.isPending}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-400">
                      <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Aucun étudiant créé</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Navigation */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/">
            <Button variant="ghost" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'Accueil
            </Button>
          </Link>
          <Link to="/admin-login">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <ShieldCheck className="w-4 h-4 mr-2" />
              Connexion Admin
            </Button>
          </Link>
          <Link to="/student-login">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <BookOpen className="w-4 h-4 mr-2" />
              Connexion Étudiant
            </Button>
          </Link>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-slate-500 mt-8">
          UNIV-SCOLAR - Panneau d'Initialisation Temporaire
          <br />
          <span className="text-amber-400/70">
            ⚠️ Supprimez cette page après l'initialisation du système
          </span>
        </p>
      </div>
    </div>
  )
}
