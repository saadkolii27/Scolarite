import { createFileRoute, Link } from '@tanstack/react-router'
import { useMutation, useQuery } from '@tanstack/react-query'
import { useServerFn } from '@tanstack/react-start'
import {
  checkSuperAdminExistsFn,
  syncSuperAdminFromDbFn,
  repairSuperAdminFn,
} from '@/server/functions/init-super-admin'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  ArrowLeft,
  RefreshCw,
  Database,
  Key,
  GraduationCap,
  ExternalLink,
  Copy,
  AlertCircle,
  Trash2,
  Users,
} from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { useState } from 'react'

export const Route = createFileRoute('/_public/setup')({
  component: SetupPage,
})

function SetupPage() {
  const [copied, setCopied] = useState(false)
  const checkSuperAdmin = useServerFn(checkSuperAdminExistsFn)
  const syncSuperAdmin = useServerFn(syncSuperAdminFromDbFn)
  const repairSuperAdmin = useServerFn(repairSuperAdminFn)

  const statusQuery = useQuery({
    queryKey: ['super-admin-status'],
    queryFn: () => checkSuperAdmin(),
    refetchOnWindowFocus: false,
  })

  const syncMutation = useMutation({
    mutationFn: () => syncSuperAdmin(),
    onSuccess: () => {
      void statusQuery.refetch()
    },
  })

  const repairMutation = useMutation({
    mutationFn: () => repairSuperAdmin(),
    onSuccess: () => {
      void statusQuery.refetch()
    },
  })

  const status = statusQuery.data

  const copyCredentials = (email: string, password: string) => {
    const text = `Email: ${email}\nMot de passe: ${password}`
    void navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Get the latest successful mutation result
  const successResult = syncMutation.data?.success
    ? syncMutation.data
    : repairMutation.data?.success
      ? repairMutation.data
      : null

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f2744] via-[#1e3a5f] to-[#2d4a6f] flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="w-full max-w-lg relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c9a227] to-[#a88420] mb-4 shadow-lg">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">
            Configuration Initiale
          </h1>
          <p className="text-slate-300 mt-2">
            UNIV-SCOLAR - Système de Gestion Universitaire
          </p>
        </div>

        <Card className="shadow-2xl border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5 text-[#1e3a5f]" />
              Synchronisation du Compte Super Admin
            </CardTitle>
            <CardDescription>
              Cette page permet de synchroniser le compte Super Administrateur
              créé dans la base de données avec le système d'authentification
              Appwrite.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Status Display */}
            {statusQuery.isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-[#1e3a5f]" />
                <span className="ml-3 text-slate-600">
                  Vérification du statut...
                </span>
              </div>
            ) : statusQuery.isError ? (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Erreur</AlertTitle>
                <AlertDescription>
                  Impossible de vérifier le statut du compte. Veuillez
                  réessayer.
                </AlertDescription>
              </Alert>
            ) : status ? (
              <div className="space-y-4">
                {/* Status Badge */}
                <div
                  className={`p-4 rounded-lg border ${
                    status.status === 'configured'
                      ? 'bg-green-50 border-green-200'
                      : status.status === 'db_only'
                        ? 'bg-amber-50 border-amber-200'
                        : status.status === 'auth_only'
                          ? 'bg-blue-50 border-blue-200'
                          : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {status.status === 'configured' ? (
                      <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                    )}
                    <div>
                      <h3
                        className={`font-semibold ${
                          status.status === 'configured'
                            ? 'text-green-800'
                            : 'text-amber-800'
                        }`}
                      >
                        {status.status === 'configured'
                          ? 'Compte Configuré ✓'
                          : status.status === 'db_only'
                            ? 'Synchronisation Requise'
                            : status.status === 'auth_only'
                              ? 'Enregistrement DB Manquant'
                              : 'Compte Non Trouvé'}
                      </h3>
                      <p
                        className={`text-sm mt-1 ${
                          status.status === 'configured'
                            ? 'text-green-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {status.message}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="bg-slate-50 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Email:</span>
                    <span className="font-mono text-slate-700">
                      {status.email}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Base de données:</span>
                    <span
                      className={
                        status.dbExists
                          ? 'text-green-600 font-medium'
                          : 'text-red-600 font-medium'
                      }
                    >
                      {status.dbExists ? '✓ Présent' : '✗ Absent'}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Appwrite Auth:</span>
                    <span
                      className={
                        status.authExists
                          ? 'text-green-600 font-medium'
                          : 'text-red-600 font-medium'
                      }
                    >
                      {status.authExists ? '✓ Présent' : '✗ Absent'}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                {status.status !== 'configured' && (
                  <div className="space-y-3">
                    <Button
                      onClick={() => syncMutation.mutate()}
                      disabled={
                        syncMutation.isPending || repairMutation.isPending
                      }
                      className="w-full bg-[#1e3a5f] hover:bg-[#2d4a6f]"
                    >
                      {syncMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Synchronisation en cours...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Synchroniser le Compte
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={() => repairMutation.mutate()}
                      disabled={
                        syncMutation.isPending || repairMutation.isPending
                      }
                      variant="outline"
                      className="w-full border-amber-300 text-amber-700 hover:bg-amber-50"
                    >
                      {repairMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Réparation en cours...
                        </>
                      ) : (
                        <>
                          <Trash2 className="w-4 h-4 mr-2" />
                          Réinitialiser Complètement
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Success Message with Credentials */}
                {successResult && (
                  <Alert className="bg-green-50 border-green-200">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800">
                      Opération Réussie !
                    </AlertTitle>
                    <AlertDescription className="text-green-700">
                      {successResult.message}
                      {successResult.credentials && (
                        <div className="mt-3 p-3 bg-white rounded border border-green-200">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Key className="w-4 h-4" />
                              <span className="font-semibold">
                                Identifiants:
                              </span>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                copyCredentials(
                                  successResult.credentials!.email,
                                  successResult.credentials!.password,
                                )
                              }
                              className="h-7 text-xs"
                            >
                              <Copy className="w-3 h-3 mr-1" />
                              {copied ? 'Copié!' : 'Copier'}
                            </Button>
                          </div>
                          <p className="text-sm font-mono">
                            Email: {successResult.credentials.email}
                          </p>
                          <p className="text-sm font-mono">
                            Mot de passe: {successResult.credentials.password}
                          </p>
                        </div>
                      )}
                    </AlertDescription>
                  </Alert>
                )}

                {/* Error Messages */}
                {syncMutation.isSuccess && !syncMutation.data?.success && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Erreur de Synchronisation</AlertTitle>
                    <AlertDescription>
                      {syncMutation.data?.message}
                    </AlertDescription>
                  </Alert>
                )}

                {repairMutation.isSuccess && !repairMutation.data?.success && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Erreur de Réparation</AlertTitle>
                    <AlertDescription>
                      {repairMutation.data?.message}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            ) : null}

            {/* Refresh Button */}
            <Button
              variant="outline"
              onClick={() => statusQuery.refetch()}
              disabled={statusQuery.isLoading}
              className="w-full"
            >
              <RefreshCw
                className={`w-4 h-4 mr-2 ${statusQuery.isLoading ? 'animate-spin' : ''}`}
              />
              Actualiser le Statut
            </Button>

            {/* Navigation */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              {(status?.status === 'configured' || successResult) && (
                <Link to="/admin-login" className="block">
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <ShieldCheck className="w-4 h-4 mr-2" />
                    Accéder à la Connexion Admin
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              )}

              <Link to="/init-accounts" className="block">
                <Button
                  variant="outline"
                  className="w-full border-blue-300 text-blue-700 hover:bg-blue-50"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Panneau d'Initialisation des Comptes
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </Link>

              <Link to="/" className="block">
                <Button variant="ghost" className="w-full">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour à l'Accueil
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Help Text */}
        <p className="text-center text-xs text-slate-400 mt-6">
          Cette page est destinée à la configuration initiale du système.
          <br />
          Une fois le compte Super Admin configuré, vous pourrez vous connecter
          normalement.
        </p>
      </div>
    </div>
  )
}
