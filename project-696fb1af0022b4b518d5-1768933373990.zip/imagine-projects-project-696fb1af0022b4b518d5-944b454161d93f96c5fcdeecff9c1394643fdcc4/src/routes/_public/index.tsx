import { createFileRoute } from '@tanstack/react-router'
import {
  HeroSection,
  AccessCards,
  FeaturesSection,
  Footer,
} from '@/components/landing'

export const Route = createFileRoute('/_public/')({
  component: Index,
})

function Index() {
  return (
    <div className="min-h-screen flex flex-col">
      <HeroSection />
      <AccessCards />
      <FeaturesSection />
      <Footer />
    </div>
  )
}
