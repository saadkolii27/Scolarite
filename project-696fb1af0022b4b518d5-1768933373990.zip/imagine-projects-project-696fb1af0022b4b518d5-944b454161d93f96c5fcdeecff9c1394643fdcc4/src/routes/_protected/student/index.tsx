import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import {
  StudentGradesCard,
  StudentAnnouncementsCard,
  StudentRequestsCard,
  StudentScheduleCard,
} from '@/components/student'
import { Award, BookOpen, Clock } from 'lucide-react'

export const Route = createFileRoute('/_protected/student/')({
  component: StudentDashboard,
})

function StudentDashboard() {
  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="bg-gradient-to-r from-[#1e3a5f] to-[#3d5a80] rounded-2xl p-6 lg:p-8 text-white">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <p className="text-white/70 mb-1">Bienvenue,</p>
              <h1 className="text-2xl lg:text-3xl font-bold font-display mb-2">
                Ahmed BENALI
              </h1>
              <p className="text-white/80">
                SMI - Semestre 4 • Année universitaire 2024-2025
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 min-w-[120px]">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="w-5 h-5 text-[#c9a227]" />
                  <span className="text-white/70 text-sm">Moyenne</span>
                </div>
                <p className="text-2xl font-bold">13.50</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 min-w-[120px]">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5 text-[#c9a227]" />
                  <span className="text-white/70 text-sm">Modules</span>
                </div>
                <p className="text-2xl font-bold">5/6</p>
                <p className="text-xs text-white/60">validés</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 min-w-[120px]">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-[#c9a227]" />
                  <span className="text-white/70 text-sm">Demandes</span>
                </div>
                <p className="text-2xl font-bold">2</p>
                <p className="text-xs text-white/60">en cours</p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        <StudentGradesCard />
        <div className="space-y-6">
          <StudentScheduleCard />
          <StudentAnnouncementsCard />
        </div>
        <div className="lg:col-span-2">
          <StudentRequestsCard />
        </div>
      </div>
    </div>
  )
}
