import { createFileRoute, Outlet, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { AdminSidebar, AdminMobileHeader } from '@/components/layout'
import { adminAuthMiddleware } from '@/server/functions/admin-auth'

export const Route = createFileRoute('/_protected/admin')({
  component: AdminLayoutComponent,
  loader: async ({ location }) => {
    const { currentAdmin } = await adminAuthMiddleware()

    if (!currentAdmin) {
      throw redirect({
        to: '/admin-login',
        search: { redirect: location.href },
      })
    }

    return { currentAdmin }
  },
})

function AdminLayoutComponent() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { currentAdmin } = Route.useLoaderData()

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminSidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        currentAdmin={currentAdmin}
      />
      <AdminMobileHeader onToggle={() => setSidebarOpen(!sidebarOpen)} />

      {/* Main Content */}
      <main className="lg:ml-72 min-h-screen pt-16 lg:pt-0">
        <Outlet />
      </main>
    </div>
  )
}
