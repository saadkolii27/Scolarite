import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'motion/react'
import {
  DashboardStats,
  RecentActivity,
  QuickActions,
  UpcomingExams,
} from '@/components/admin'
import { Calendar, Bell } from 'lucide-react'
import { Button } from '@/components/ui/button'

export const Route = createFileRoute('/_protected/admin/')({
  component: AdminDashboard,
})

function AdminDashboard() {
  const today = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 font-display">
              Tableau de bord
            </h1>
            <p className="text-slate-500 mt-1 flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span className="capitalize">{today}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="gap-2">
              <Bell className="w-4 h-4" />
              <span className="hidden sm:inline">Notifications</span>
              <span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                3
              </span>
            </Button>
            <Button className="bg-[#1e3a5f] hover:bg-[#0f2744]">
              Année 2024-2025
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="mb-8">
        <DashboardStats />
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Column - 2/3 */}
        <div className="lg:col-span-2 space-y-6">
          <QuickActions />
          <UpcomingExams />
        </div>

        {/* Right Column - 1/3 */}
        <div className="space-y-6">
          <RecentActivity />
        </div>
      </div>
    </div>
  )
}
