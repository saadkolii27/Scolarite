import { createFileRoute, Outlet, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { StudentSidebar, StudentMobileHeader } from '@/components/layout'
import { studentAuthMiddleware } from '@/server/functions/student-auth'

export const Route = createFileRoute('/_protected/student')({
  component: StudentLayoutComponent,
  loader: async ({ location }) => {
    const { currentStudent } = await studentAuthMiddleware()

    if (!currentStudent) {
      throw redirect({
        to: '/student-login',
        search: { redirect: location.href },
      })
    }

    return { currentStudent }
  },
})

function StudentLayoutComponent() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { currentStudent } = Route.useLoaderData()

  return (
    <div className="min-h-screen bg-slate-50">
      <StudentSidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        currentStudent={currentStudent}
      />
      <StudentMobileHeader onToggle={() => setSidebarOpen(!sidebarOpen)} />

      {/* Main Content */}
      <main className="lg:ml-64 min-h-screen pt-16 lg:pt-0">
        <Outlet />
      </main>
    </div>
  )
}
