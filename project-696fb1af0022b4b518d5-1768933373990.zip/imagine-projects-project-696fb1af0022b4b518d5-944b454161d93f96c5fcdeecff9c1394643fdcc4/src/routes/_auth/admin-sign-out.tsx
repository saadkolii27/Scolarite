import { createFileRoute, useNavigate, useRouter } from '@tanstack/react-router'
import { useEffect } from 'react'
import { useMutation } from '@tanstack/react-query'
import { useServerFn } from '@tanstack/react-start'
import { adminSignOutFn } from '@/server/functions/admin-auth'
import { GraduationCap, Loader2 } from 'lucide-react'

export const Route = createFileRoute('/_auth/admin-sign-out')({
  component: AdminSignOutPage,
})

function AdminSignOutPage() {
  const navigate = useNavigate()
  const router = useRouter()
  const signOut = useServerFn(adminSignOutFn)

  const signOutMutation = useMutation({
    mutationFn: async () => {
      await signOut()
    },
    onSuccess: async () => {
      await router.invalidate()
      await navigate({ to: '/' })
    },
    onError: async () => {
      // Even on error, try to navigate away
      await router.invalidate()
      await navigate({ to: '/' })
    },
  })

  useEffect(() => {
    signOutMutation.mutate()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f2744] via-[#1e3a5f] to-[#2d4a6f] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center mx-auto mb-6">
          <GraduationCap className="w-8 h-8 text-white" />
        </div>
        <div className="flex items-center justify-center gap-3 text-white">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-lg">Déconnexion en cours...</span>
        </div>
        <p className="text-white/50 text-sm mt-4">
          Vous allez être redirigé vers la page d'accueil
        </p>
      </div>
    </div>
  )
}
