import { useMutation } from '@tanstack/react-query'
import {
  createFileRoute,
  Link,
  useNavigate,
  useRouter,
  useSearch,
} from '@tanstack/react-router'
import { z } from 'zod'
import { UnivScolarAuthCard } from '@/components/auth/UnivScolarAuthCard'
import { AuthForm } from '@/components/auth/auth-form'
import { AuthField } from '@/components/auth/auth-field'
import { adminSignInFn } from '@/server/functions/admin-auth'
import { useServerFn } from '@tanstack/react-start'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { ShieldCheck, ArrowLeft, AlertCircle, Settings } from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

const searchSchema = z.object({
  redirect: z.string().optional(),
})

export const Route = createFileRoute('/_auth/admin-login')({
  component: AdminLoginPage,
  validateSearch: searchSchema,
})

const adminSignInSchema = z.object({
  email: z.string().email('Veuillez entrer une adresse email valide'),
  password: z.string().min(1, 'Le mot de passe est requis'),
})

// Error code to user-friendly message mapping
const ERROR_MESSAGES: Record<
  string,
  { title: string; description: string; showSetupLink?: boolean }
> = {
  USER_NOT_FOUND: {
    title: 'Compte non trouvé',
    description:
      "Aucun compte administrateur n'est associé à cette adresse email.",
  },
  ACCOUNT_DISABLED: {
    title: 'Compte désactivé',
    description: 'Votre compte a été désactivé. Contactez un administrateur.',
  },
  INSUFFICIENT_ROLE: {
    title: 'Accès refusé',
    description:
      "Vous n'avez pas les permissions pour accéder à l'espace administrateur.",
  },
  INVALID_PASSWORD: {
    title: 'Mot de passe incorrect',
    description: 'Le mot de passe saisi est incorrect. Veuillez réessayer.',
  },
  AUTH_NOT_SYNCED: {
    title: 'Compte non synchronisé',
    description:
      "Votre compte n'est pas encore configuré dans le système d'authentification.",
    showSetupLink: true,
  },
  RATE_LIMITED: {
    title: 'Trop de tentatives',
    description: 'Veuillez patienter quelques minutes avant de réessayer.',
  },
  USER_BLOCKED: {
    title: 'Compte bloqué',
    description: 'Votre compte a été bloqué. Contactez un administrateur.',
  },
  EMAIL_MISMATCH: {
    title: 'Erreur de synchronisation',
    description:
      'Problème de configuration du compte. Contactez le service informatique.',
  },
  AUTH_ERROR: {
    title: "Erreur d'authentification",
    description: 'Impossible de vous authentifier. Vérifiez vos identifiants.',
  },
  UNEXPECTED_ERROR: {
    title: 'Erreur inattendue',
    description: 'Une erreur est survenue. Veuillez réessayer plus tard.',
  },
}

function AdminLoginPage() {
  const search = useSearch({ from: '/_auth/admin-login' })
  const navigate = useNavigate()
  const router = useRouter()
  const signIn = useServerFn(adminSignInFn)

  const form = useForm({
    resolver: zodResolver(adminSignInSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  })

  const signInMutation = useMutation({
    mutationFn: async (data: z.infer<typeof adminSignInSchema>) => {
      await signIn({
        data: { ...data, redirect: search.redirect },
      })
    },
    onSuccess: async () => {
      await router.invalidate()
      if (search.redirect) {
        await navigate({ to: search.redirect })
      } else {
        await navigate({ to: '/admin' })
      }
    },
    onError: async (error: {
      status?: number
      redirect?: boolean
      message?: string
      code?: string
      to?: string
    }) => {
      // Check if it's a redirect (successful login)
      if (error?.to || error?.status === 302 || error?.redirect) {
        await router.invalidate()
        await navigate({ to: search.redirect || '/admin' })
        return
      }

      // Get error info based on code
      const errorCode = error?.code || 'AUTH_ERROR'
      const errorInfo = ERROR_MESSAGES[errorCode] || ERROR_MESSAGES.AUTH_ERROR

      console.error('Admin sign in error:', error)
      form.setError('root', {
        message: error?.message || errorInfo.description,
        type: errorCode,
      })
    },
  })

  // Get current error info for display
  const currentError = form.formState.errors.root
  const errorCode = currentError?.type || ''
  const errorInfo = ERROR_MESSAGES[errorCode as keyof typeof ERROR_MESSAGES]

  return (
    <UnivScolarAuthCard
      title="Connexion Administrateur"
      description="Entrez vos identifiants pour accéder à l'espace de gestion"
      variant="admin"
    >
      {/* Role Badge */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <div className="flex items-center gap-2 px-4 py-2 bg-[#1e3a5f]/10 rounded-full">
          <ShieldCheck className="w-4 h-4 text-[#1e3a5f]" />
          <span className="text-sm font-medium text-[#1e3a5f]">
            Espace Administrateur
          </span>
        </div>
      </div>

      {/* Error Alert */}
      {currentError && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{errorInfo?.title || 'Erreur de connexion'}</AlertTitle>
          <AlertDescription className="mt-1">
            {currentError.message}
            {errorInfo?.showSetupLink && (
              <Link
                to="/setup"
                className="block mt-2 text-sm underline hover:no-underline"
              >
                → Accéder à la page de configuration
              </Link>
            )}
          </AlertDescription>
        </Alert>
      )}

      <AuthForm
        schema={adminSignInSchema}
        defaultValues={{
          email: '',
          password: '',
        }}
        onSubmit={(data) => {
          // Clear previous errors
          form.clearErrors('root')
          signInMutation.mutate(data)
        }}
        submitText="Se connecter"
        loadingText="Connexion en cours..."
        isLoading={signInMutation.isPending}
        form={form}
      >
        {(form) => (
          <>
            <AuthField
              control={form.control}
              name="email"
              label="Adresse email"
              placeholder="votre.email@universite.ma"
              type="email"
              autoComplete="email"
            />

            <AuthField
              control={form.control}
              name="password"
              label="Mot de passe"
              placeholder="Entrez votre mot de passe"
              type="password"
              autoComplete="current-password"
            />
          </>
        )}
      </AuthForm>

      {/* Back to home link */}
      <div className="mt-6 pt-4 border-t border-slate-200">
        <Link
          to="/"
          className="flex items-center justify-center gap-2 text-sm text-slate-500 hover:text-[#1e3a5f] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Retour à l'accueil</span>
        </Link>
      </div>

      {/* Help text */}
      <p className="text-center text-xs text-slate-400 mt-4">
        Problème de connexion ? Contactez le service informatique
      </p>

      {/* Setup link for initial configuration */}
      <div className="mt-4 text-center">
        <Link
          to="/setup"
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#1e3a5f] transition-colors"
        >
          <Settings className="w-3 h-3" />
          <span>Configuration initiale du système</span>
        </Link>
      </div>
    </UnivScolarAuthCard>
  )
}
