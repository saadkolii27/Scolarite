import { useMutation } from '@tanstack/react-query'
import {
  createFileRoute,
  Link,
  useNavigate,
  useRouter,
  useSearch,
} from '@tanstack/react-router'
import { z } from 'zod'
import { UnivScolarAuthCard } from '@/components/auth/UnivScolarAuthCard'
import { AuthForm } from '@/components/auth/auth-form'
import { AuthField } from '@/components/auth/auth-field'
import { studentSignInFn } from '@/server/functions/student-auth'
import { useServerFn } from '@tanstack/react-start'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { GraduationCap, ArrowLeft, Info, AlertCircle } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'

const searchSchema = z.object({
  redirect: z.string().optional(),
})

export const Route = createFileRoute('/_auth/student-login')({
  component: StudentLoginPage,
  validateSearch: searchSchema,
})

const studentSignInSchema = z.object({
  apogeeCode: z
    .string()
    .min(1, 'Le code Apogée est requis')
    .regex(/^[0-9]+$/, 'Le code Apogée doit contenir uniquement des chiffres'),
  cin: z.string().min(1, 'Le CIN est requis'),
})

function StudentLoginPage() {
  const search = useSearch({ from: '/_auth/student-login' })
  const navigate = useNavigate()
  const router = useRouter()
  const signIn = useServerFn(studentSignInFn)

  const form = useForm({
    resolver: zodResolver(studentSignInSchema),
    defaultValues: {
      apogeeCode: '',
      cin: '',
    },
  })

  const signInMutation = useMutation({
    mutationFn: async (data: z.infer<typeof studentSignInSchema>) => {
      await signIn({
        data: { ...data, redirect: search.redirect },
      })
    },
    onSuccess: async () => {
      await router.invalidate()
      if (search.redirect) {
        await navigate({ to: search.redirect })
      } else {
        await navigate({ to: '/student' })
      }
    },
    onError: async (error: {
      status?: number
      redirect?: boolean
      message?: string
      to?: string
    }) => {
      // Check if it's a redirect (successful login)
      if (error?.to || error?.status === 302 || error?.redirect) {
        await router.invalidate()
        await navigate({ to: search.redirect || '/student' })
        return
      }

      // Handle specific error messages
      let errorMessage = 'Échec de la connexion. Veuillez réessayer.'

      if (error?.message) {
        errorMessage = error.message
      } else if (error?.status === 401) {
        errorMessage = 'Code Apogée ou CIN incorrect.'
      } else if (error?.status === 403) {
        errorMessage = 'Votre compte étudiant est inactif.'
      }

      console.error('Student sign in error:', error)
      form.setError('root', { message: errorMessage })
    },
  })

  return (
    <UnivScolarAuthCard
      title="Connexion Étudiant"
      description="Utilisez votre code Apogée et CIN pour accéder à votre espace"
      variant="student"
    >
      {/* Role Badge */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <div className="flex items-center gap-2 px-4 py-2 bg-[#3d5a80]/10 rounded-full">
          <GraduationCap className="w-4 h-4 text-[#3d5a80]" />
          <span className="text-sm font-medium text-[#3d5a80]">
            Espace Étudiant
          </span>
        </div>
      </div>

      {/* Error Alert */}
      {form.formState.errors.root && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {form.formState.errors.root.message}
          </AlertDescription>
        </Alert>
      )}

      <AuthForm
        schema={studentSignInSchema}
        defaultValues={{
          apogeeCode: '',
          cin: '',
        }}
        onSubmit={(data) => {
          // Clear previous errors
          form.clearErrors('root')
          signInMutation.mutate(data)
        }}
        submitText="Se connecter"
        loadingText="Connexion en cours..."
        isLoading={signInMutation.isPending}
        form={form}
      >
        {(form) => (
          <>
            <AuthField
              control={form.control}
              name="apogeeCode"
              label="Code Apogée"
              placeholder="Ex: 12345678"
              type="text"
              autoComplete="username"
            />

            <AuthField
              control={form.control}
              name="cin"
              label="CIN (Carte d'Identité Nationale)"
              placeholder="Ex: AB123456"
              type="text"
              autoComplete="off"
            />
          </>
        )}
      </AuthForm>

      {/* Info box */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <div className="flex gap-3">
          <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-700">
            <p className="font-medium mb-1">
              Comment trouver vos identifiants ?
            </p>
            <ul className="text-blue-600 space-y-1 text-xs">
              <li>
                • <strong>Code Apogée</strong> : figurant sur votre carte
                d'étudiant
              </li>
              <li>
                • <strong>CIN</strong> : numéro de votre carte d'identité
                nationale
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Back to home link */}
      <div className="mt-6 pt-4 border-t border-slate-200">
        <Link
          to="/"
          className="flex items-center justify-center gap-2 text-sm text-slate-500 hover:text-[#1e3a5f] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Retour à l'accueil</span>
        </Link>
      </div>

      {/* Help text */}
      <p className="text-center text-xs text-slate-400 mt-4">
        Problème de connexion ? Contactez le service scolarité
      </p>
    </UnivScolarAuthCard>
  )
}
