import { createFileRoute, useNavigate, useRouter } from '@tanstack/react-router'
import { useEffect } from 'react'
import { useMutation } from '@tanstack/react-query'
import { useServerFn } from '@tanstack/react-start'
import { studentSignOutFn } from '@/server/functions/student-auth'
import { GraduationCap, Loader2 } from 'lucide-react'

export const Route = createFileRoute('/_auth/student-sign-out')({
  component: StudentSignOutPage,
})

function StudentSignOutPage() {
  const navigate = useNavigate()
  const router = useRouter()
  const signOut = useServerFn(studentSignOutFn)

  const signOutMutation = useMutation({
    mutationFn: async () => {
      await signOut()
    },
    onSuccess: async () => {
      await router.invalidate()
      await navigate({ to: '/' })
    },
    onError: async () => {
      // Even on error, try to navigate away
      await router.invalidate()
      await navigate({ to: '/' })
    },
  })

  useEffect(() => {
    signOutMutation.mutate()
  }, [])

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#1e3a5f] to-[#3d5a80] flex items-center justify-center mx-auto mb-6">
          <GraduationCap className="w-8 h-8 text-white" />
        </div>
        <div className="flex items-center justify-center gap-3 text-[#1e3a5f]">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-lg">Déconnexion en cours...</span>
        </div>
        <p className="text-slate-500 text-sm mt-4">
          Vous allez être redirigé vers la page d'accueil
        </p>
      </div>
    </div>
  )
}
