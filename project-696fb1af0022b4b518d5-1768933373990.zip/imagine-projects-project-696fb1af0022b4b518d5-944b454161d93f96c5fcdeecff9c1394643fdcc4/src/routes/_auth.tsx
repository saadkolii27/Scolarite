import { getCurrentUser } from '@/server/functions/auth'
import { getCurrentAdminFn } from '@/server/functions/admin-auth'
import { getCurrentStudentFn } from '@/server/functions/student-auth'
import { redirect } from '@tanstack/react-router'
import { createFileRoute, Outlet } from '@tanstack/react-router'

export const Route = createFileRoute('/_auth')({
  component: AuthLayout,
  loader: async ({ location }) => {
    const pathname = location.pathname

    // Sign-out pages should always be accessible
    if (pathname.includes('sign-out')) {
      return { currentUser: null }
    }

    // Check for admin login page
    if (pathname === '/admin-login') {
      const currentAdmin = await getCurrentAdminFn()
      if (currentAdmin) {
        // Already logged in as admin, redirect to admin dashboard
        throw redirect({ to: '/admin' })
      }
      return { currentUser: null }
    }

    // Check for student login page
    if (pathname === '/student-login') {
      const currentStudent = await getCurrentStudentFn()
      if (currentStudent) {
        // Already logged in as student, redirect to student dashboard
        throw redirect({ to: '/student' })
      }
      return { currentUser: null }
    }

    // Default behavior for other auth pages (sign-in, sign-up)
    const currentUser = await getCurrentUser()
    if (currentUser && pathname !== '/sign-out') {
      throw redirect({ to: '/' })
    }

    return { currentUser }
  },
})

function AuthLayout() {
  return <Outlet />
}
