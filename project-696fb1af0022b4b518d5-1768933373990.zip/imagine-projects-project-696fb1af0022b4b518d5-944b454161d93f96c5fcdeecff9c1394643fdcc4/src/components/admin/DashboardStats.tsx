import { motion } from 'motion/react'
import {
  Users,
  GraduationCap,
  FileText,
  ClipboardCheck,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface StatCardProps {
  title: string
  value: string
  change?: number
  changeLabel?: string
  icon: React.ElementType
  color: string
  delay?: number
}

function StatCard({
  title,
  value,
  change,
  changeLabel,
  icon: Icon,
  color,
  delay = 0,
}: StatCardProps) {
  const TrendIcon =
    change && change > 0
      ? TrendingUp
      : change && change < 0
        ? TrendingDown
        : Minus
  const trendColor =
    change && change > 0
      ? 'text-green-600'
      : change && change < 0
        ? 'text-red-600'
        : 'text-slate-400'

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${color}15` }}
        >
          <Icon className="w-6 h-6" style={{ color }} />
        </div>
        {change !== undefined && (
          <div className={cn('flex items-center gap-1 text-sm', trendColor)}>
            <TrendIcon className="w-4 h-4" />
            <span className="font-medium">{Math.abs(change)}%</span>
          </div>
        )}
      </div>
      <h3 className="text-3xl font-bold text-slate-900 mb-1">{value}</h3>
      <p className="text-sm text-slate-500">{title}</p>
      {changeLabel && (
        <p className="text-xs text-slate-400 mt-2">{changeLabel}</p>
      )}
    </motion.div>
  )
}

export function DashboardStats() {
  const stats = [
    {
      title: 'Étudiants inscrits',
      value: '2,847',
      change: 12,
      changeLabel: 'vs. année précédente',
      icon: Users,
      color: '#1e3a5f',
    },
    {
      title: 'Examens planifiés',
      value: '156',
      change: 8,
      changeLabel: 'ce semestre',
      icon: ClipboardCheck,
      color: '#c9a227',
    },
    {
      title: 'Notes saisies',
      value: '12,450',
      change: -3,
      changeLabel: 'en attente: 234',
      icon: GraduationCap,
      color: '#2a9d8f',
    },
    {
      title: 'Demandes en cours',
      value: '89',
      change: 0,
      changeLabel: "traitées aujourd'hui: 12",
      icon: FileText,
      color: '#e76f51',
    },
  ]

  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} delay={index * 0.1} />
      ))}
    </div>
  )
}
