import { motion } from 'motion/react'
import { Link } from '@tanstack/react-router'
import {
  FileText,
  Calendar,
  BarChart3,
  RefreshCw,
  Bell,
  Search,
} from 'lucide-react'

const quickActions = [
  {
    label: 'Nouvelle demande',
    description: 'Traiter une demande de document',
    icon: FileText,
    href: '/admin/scolarite/demandes',
    color: '#1e3a5f',
  },
  {
    label: 'Rechercher étudiant',
    description: 'Accéder au dossier étudiant',
    icon: Search,
    href: '/admin/scolarite/recherche',
    color: '#3d5a80',
  },
  {
    label: 'Saisir notes',
    description: 'Gestion des notes par module',
    icon: BarChart3,
    href: '/admin/resultats/notes',
    color: '#c9a227',
  },
  {
    label: 'Planifier examen',
    description: "Créer une séance d'examen",
    icon: Calendar,
    href: '/admin/examens/seances',
    color: '#2a9d8f',
  },
  {
    label: 'Sync. Apogée',
    description: 'Synchroniser les données',
    icon: RefreshCw,
    href: '/admin/apogee/etudiants',
    color: '#e76f51',
  },
  {
    label: 'Publier avis',
    description: 'Créer une annonce',
    icon: Bell,
    href: '/admin/avis',
    color: '#9c6644',
  },
]

export function QuickActions() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-lg font-semibold text-slate-900">
          Actions rapides
        </h2>
      </div>
      <div className="p-4 grid grid-cols-2 lg:grid-cols-3 gap-3">
        {quickActions.map((action, index) => (
          <Link key={index} to={action.href}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: 0.4 + index * 0.05 }}
              className="group p-4 rounded-xl border border-slate-100 hover:border-slate-200 hover:shadow-md transition-all cursor-pointer"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-3 transition-transform group-hover:scale-110"
                style={{ backgroundColor: `${action.color}15` }}
              >
                <action.icon
                  className="w-5 h-5"
                  style={{ color: action.color }}
                />
              </div>
              <h3 className="font-medium text-slate-900 text-sm mb-1 group-hover:text-[#1e3a5f] transition-colors">
                {action.label}
              </h3>
              <p className="text-xs text-slate-500">{action.description}</p>
            </motion.div>
          </Link>
        ))}
      </div>
    </motion.div>
  )
}
