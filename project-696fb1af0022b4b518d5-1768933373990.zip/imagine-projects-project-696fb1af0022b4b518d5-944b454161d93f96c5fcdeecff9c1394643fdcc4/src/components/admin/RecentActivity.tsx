import { motion } from 'motion/react'
import {
  FileText,
  UserPlus,
  CheckCircle,
  AlertCircle,
  Clock,
  RefreshCw,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface ActivityItem {
  id: string
  type: 'document' | 'student' | 'grade' | 'alert' | 'sync'
  title: string
  description: string
  time: string
  status?: 'success' | 'warning' | 'pending'
}

const activities: ActivityItem[] = [
  {
    id: '1',
    type: 'grade',
    title: 'Notes publiées',
    description: 'Module Analyse Numérique - S3',
    time: 'Il y a 5 min',
    status: 'success',
  },
  {
    id: '2',
    type: 'document',
    title: 'Demande de certificat',
    description: 'Ahmed BENALI - Certificat de scolarité',
    time: 'Il y a 15 min',
    status: 'pending',
  },
  {
    id: '3',
    type: 'sync',
    title: 'Synchronisation Apogée',
    description: '245 étudiants synchronisés',
    time: 'Il y a 30 min',
    status: 'success',
  },
  {
    id: '4',
    type: 'alert',
    title: 'Réclamation reçue',
    description: 'Note contestée - Algèbre S2',
    time: 'Il y a 1h',
    status: 'warning',
  },
  {
    id: '5',
    type: 'student',
    title: 'Nouvelle inscription',
    description: 'Fatima ZAHRA - SMI S1',
    time: 'Il y a 2h',
    status: 'success',
  },
]

const iconMap = {
  document: FileText,
  student: UserPlus,
  grade: CheckCircle,
  alert: AlertCircle,
  sync: RefreshCw,
}

const colorMap = {
  document: '#3d5a80',
  student: '#2a9d8f',
  grade: '#c9a227',
  alert: '#e76f51',
  sync: '#1e3a5f',
}

const statusColorMap = {
  success: 'bg-green-100 text-green-700',
  warning: 'bg-amber-100 text-amber-700',
  pending: 'bg-blue-100 text-blue-700',
}

export function RecentActivity() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">
            Activité récente
          </h2>
          <button className="text-sm text-[#1e3a5f] hover:underline font-medium">
            Voir tout
          </button>
        </div>
      </div>
      <div className="divide-y divide-slate-100">
        {activities.map((activity, index) => {
          const Icon = iconMap[activity.type]
          const color = colorMap[activity.type]

          return (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.5 + index * 0.05 }}
              className="p-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${color}15` }}
                >
                  <Icon className="w-5 h-5" style={{ color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium text-slate-900 text-sm">
                      {activity.title}
                    </h3>
                    {activity.status && (
                      <span
                        className={cn(
                          'px-2 py-0.5 rounded-full text-xs font-medium',
                          statusColorMap[activity.status],
                        )}
                      >
                        {activity.status === 'success'
                          ? 'Terminé'
                          : activity.status === 'warning'
                            ? 'Attention'
                            : 'En cours'}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 truncate">
                    {activity.description}
                  </p>
                </div>
                <div className="flex items-center gap-1 text-xs text-slate-400 flex-shrink-0">
                  <Clock className="w-3 h-3" />
                  <span>{activity.time}</span>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
