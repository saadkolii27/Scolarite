import { motion } from 'motion/react'
import { Construction, ArrowLeft } from 'lucide-react'
import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'

interface ComingSoonProps {
  title: string
  description?: string
}

export function ComingSoon({ title, description }: ComingSoonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-[60vh] text-center px-6"
    >
      <div className="w-20 h-20 rounded-2xl bg-[#c9a227]/10 flex items-center justify-center mb-6">
        <Construction className="w-10 h-10 text-[#c9a227]" />
      </div>
      <h2 className="text-2xl font-bold text-slate-900 font-display mb-2">
        {title}
      </h2>
      <p className="text-slate-500 max-w-md mb-8">
        {description ||
          'Ce module est en cours de développement et sera disponible prochainement.'}
      </p>
      <Link to="/admin">
        <Button variant="outline" className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Retour au tableau de bord
        </Button>
      </Link>
    </motion.div>
  )
}
