import { motion } from 'motion/react'
import { Calendar, Clock, MapPin, Users } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Exam {
  id: string
  module: string
  filiere: string
  date: string
  time: string
  room: string
  students: number
  status: 'upcoming' | 'today' | 'ongoing'
}

const exams: Exam[] = [
  {
    id: '1',
    module: 'Analyse Numérique',
    filiere: 'SMI - S3',
    date: "Aujourd'hui",
    time: '09:00 - 11:00',
    room: 'Amphi A',
    students: 120,
    status: 'today',
  },
  {
    id: '2',
    module: 'Programmation Java',
    filiere: 'SMI - S4',
    date: "Aujourd'hui",
    time: '14:00 - 16:00',
    room: 'Salle 12',
    students: 85,
    status: 'today',
  },
  {
    id: '3',
    module: 'Base de données',
    filiere: 'SMA - S3',
    date: 'Demain',
    time: '09:00 - 11:00',
    room: 'Amphi B',
    students: 95,
    status: 'upcoming',
  },
  {
    id: '4',
    module: 'Algèbre Linéaire',
    filiere: 'SMI - S2',
    date: '15 Jan 2025',
    time: '10:00 - 12:00',
    room: 'Salle 8',
    students: 110,
    status: 'upcoming',
  },
]

const statusStyles = {
  today: 'bg-amber-100 text-amber-700 border-amber-200',
  upcoming: 'bg-blue-100 text-blue-700 border-blue-200',
  ongoing: 'bg-green-100 text-green-700 border-green-200',
}

const statusLabels = {
  today: "Aujourd'hui",
  upcoming: 'À venir',
  ongoing: 'En cours',
}

export function UpcomingExams() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">
            Examens à venir
          </h2>
          <button className="text-sm text-[#1e3a5f] hover:underline font-medium">
            Voir planning
          </button>
        </div>
      </div>
      <div className="divide-y divide-slate-100">
        {exams.map((exam, index) => (
          <motion.div
            key={exam.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.6 + index * 0.05 }}
            className="p-4 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-medium text-slate-900">{exam.module}</h3>
                <p className="text-sm text-slate-500">{exam.filiere}</p>
              </div>
              <span
                className={cn(
                  'px-2.5 py-1 rounded-full text-xs font-medium border',
                  statusStyles[exam.status],
                )}
              >
                {statusLabels[exam.status]}
              </span>
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-slate-500">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>{exam.date}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>{exam.time}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-slate-400" />
                <span>{exam.room}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-slate-400" />
                <span>{exam.students} étudiants</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}
