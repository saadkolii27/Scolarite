import { motion } from 'motion/react'
import { Bell, Calendar, Pin, ExternalLink } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Announcement {
  id: string
  title: string
  excerpt: string
  date: string
  type: 'urgent' | 'info' | 'exam'
  isPinned?: boolean
}

const announcements: Announcement[] = [
  {
    id: '1',
    title: 'Calendrier des examens S4',
    excerpt:
      'Le calendrier des examens de la session normale S4 est disponible.',
    date: '10 Jan 2025',
    type: 'exam',
    isPinned: true,
  },
  {
    id: '2',
    title: 'Inscription aux rattrapages',
    excerpt:
      "Les inscriptions aux examens de rattrapage sont ouvertes jusqu'au 20 janvier.",
    date: '08 Jan 2025',
    type: 'urgent',
  },
  {
    id: '3',
    title: 'Changement de salle - Cours Java',
    excerpt:
      'Le cours de Programmation Java du mercredi se tiendra en salle 15.',
    date: '05 Jan 2025',
    type: 'info',
  },
]

const typeConfig = {
  urgent: { label: 'Urgent', color: 'bg-red-100 text-red-700 border-red-200' },
  info: { label: 'Info', color: 'bg-blue-100 text-blue-700 border-blue-200' },
  exam: {
    label: 'Examen',
    color: 'bg-amber-100 text-amber-700 border-amber-200',
  },
}

export function StudentAnnouncementsCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#e76f51]/10 flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#e76f51]" />
            </div>
            <h2 className="text-lg font-semibold text-slate-900">
              Avis & Annonces
            </h2>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-red-100 text-red-700 text-xs font-medium">
            3 nouveaux
          </span>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {announcements.map((announcement, index) => (
          <motion.div
            key={announcement.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.4 + index * 0.05 }}
            className="p-4 hover:bg-slate-50 transition-colors cursor-pointer group"
          >
            <div className="flex items-start gap-3">
              {announcement.isPinned && (
                <Pin className="w-4 h-4 text-[#c9a227] flex-shrink-0 mt-1" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-medium text-slate-900 group-hover:text-[#1e3a5f] transition-colors truncate">
                    {announcement.title}
                  </h3>
                  <span
                    className={cn(
                      'px-2 py-0.5 rounded-full text-xs font-medium border flex-shrink-0',
                      typeConfig[announcement.type].color,
                    )}
                  >
                    {typeConfig[announcement.type].label}
                  </span>
                </div>
                <p className="text-sm text-slate-500 line-clamp-2 mb-2">
                  {announcement.excerpt}
                </p>
                <div className="flex items-center gap-1 text-xs text-slate-400">
                  <Calendar className="w-3 h-3" />
                  <span>{announcement.date}</span>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-[#1e3a5f] transition-colors flex-shrink-0" />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <button className="w-full text-center text-sm text-[#1e3a5f] font-medium hover:underline">
          Voir tous les avis →
        </button>
      </div>
    </motion.div>
  )
}
