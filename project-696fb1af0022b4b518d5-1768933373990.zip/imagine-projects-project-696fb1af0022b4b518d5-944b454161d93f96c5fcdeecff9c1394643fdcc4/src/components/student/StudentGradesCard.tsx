import { motion } from 'motion/react'
import { BarChart3 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Grade {
  module: string
  code: string
  note: number | null
  status: 'validated' | 'pending' | 'failed'
}

const grades: Grade[] = [
  {
    module: 'Analyse Numérique',
    code: 'AN301',
    note: 15.5,
    status: 'validated',
  },
  {
    module: 'Programmation Java',
    code: 'PJ302',
    note: 14.0,
    status: 'validated',
  },
  { module: 'Base de données', code: 'BD303', note: null, status: 'pending' },
  { module: 'Algèbre Linéaire', code: 'AL304', note: 8.5, status: 'failed' },
  { module: 'Réseaux', code: 'RS305', note: 16.0, status: 'validated' },
]

const statusConfig = {
  validated: { label: 'Validé', color: 'text-green-600 bg-green-100' },
  pending: { label: 'En attente', color: 'text-amber-600 bg-amber-100' },
  failed: { label: 'Non validé', color: 'text-red-600 bg-red-100' },
}

export function StudentGradesCard() {
  const average =
    grades
      .filter((g) => g.note !== null)
      .reduce((acc, g) => acc + (g.note || 0), 0) /
    grades.filter((g) => g.note !== null).length

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#c9a227]/10 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-[#c9a227]" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                Mes Notes - S4
              </h2>
              <p className="text-sm text-slate-500">
                Session Normale 2024-2025
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-[#1e3a5f]">
              {average.toFixed(2)}
            </p>
            <p className="text-xs text-slate-500">Moyenne générale</p>
          </div>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {grades.map((grade, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 + index * 0.05 }}
            className="p-4 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-slate-900">{grade.module}</h3>
                <p className="text-sm text-slate-500">{grade.code}</p>
              </div>
              <div className="flex items-center gap-3">
                {grade.note !== null ? (
                  <span
                    className={cn(
                      'text-xl font-bold',
                      grade.note >= 10 ? 'text-green-600' : 'text-red-600',
                    )}
                  >
                    {grade.note.toFixed(2)}
                  </span>
                ) : (
                  <span className="text-slate-400">--</span>
                )}
                <span
                  className={cn(
                    'px-2.5 py-1 rounded-full text-xs font-medium',
                    statusConfig[grade.status].color,
                  )}
                >
                  {statusConfig[grade.status].label}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <button className="w-full text-center text-sm text-[#1e3a5f] font-medium hover:underline">
          Voir toutes mes notes →
        </button>
      </div>
    </motion.div>
  )
}
