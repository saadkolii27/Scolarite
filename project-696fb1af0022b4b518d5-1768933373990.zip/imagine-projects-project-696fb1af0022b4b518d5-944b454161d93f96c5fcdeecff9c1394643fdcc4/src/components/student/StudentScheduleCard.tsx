import { motion } from 'motion/react'
import { Calendar, MapPin, BookOpen } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ScheduleItem {
  id: string
  subject: string
  type: 'cours' | 'td' | 'tp' | 'exam'
  time: string
  room: string
  professor?: string
}

const todaySchedule: ScheduleItem[] = [
  {
    id: '1',
    subject: 'Analyse Numérique',
    type: 'cours',
    time: '08:30 - 10:00',
    room: 'Amphi A',
    professor: 'Pr. ALAMI',
  },
  {
    id: '2',
    subject: 'Programmation Java',
    type: 'tp',
    time: '10:15 - 12:15',
    room: 'Salle Info 3',
    professor: 'Pr. BENNANI',
  },
  {
    id: '3',
    subject: 'Base de données',
    type: 'td',
    time: '14:00 - 15:30',
    room: 'Salle 12',
    professor: 'Pr. FASSI',
  },
]

const typeConfig = {
  cours: { label: 'Cours', color: 'bg-blue-100 text-blue-700' },
  td: { label: 'TD', color: 'bg-green-100 text-green-700' },
  tp: { label: 'TP', color: 'bg-purple-100 text-purple-700' },
  exam: { label: 'Examen', color: 'bg-red-100 text-red-700' },
}

export function StudentScheduleCard() {
  const today = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  })

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2a9d8f]/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-[#2a9d8f]" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                Emploi du temps
              </h2>
              <p className="text-sm text-slate-500 capitalize">{today}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {todaySchedule.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.6 + index * 0.05 }}
            className="flex gap-4 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors"
          >
            <div className="flex flex-col items-center justify-center min-w-[60px] text-center">
              <span className="text-xs text-slate-500">
                {item.time.split(' - ')[0]}
              </span>
              <div className="w-px h-4 bg-slate-300 my-1" />
              <span className="text-xs text-slate-500">
                {item.time.split(' - ')[1]}
              </span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium text-slate-900">{item.subject}</h3>
                <span
                  className={cn(
                    'px-2 py-0.5 rounded text-xs font-medium',
                    typeConfig[item.type].color,
                  )}
                >
                  {typeConfig[item.type].label}
                </span>
              </div>
              <div className="flex items-center gap-4 text-sm text-slate-500">
                <div className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{item.room}</span>
                </div>
                {item.professor && (
                  <div className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{item.professor}</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <button className="w-full text-center text-sm text-[#1e3a5f] font-medium hover:underline">
          Voir l'emploi du temps complet →
        </button>
      </div>
    </motion.div>
  )
}
