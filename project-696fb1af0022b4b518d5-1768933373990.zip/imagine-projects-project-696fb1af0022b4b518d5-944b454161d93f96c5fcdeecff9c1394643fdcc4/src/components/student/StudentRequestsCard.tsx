import { motion } from 'motion/react'
import { FileText, Clock, CheckCircle, XCircle, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

interface Request {
  id: string
  type: string
  date: string
  status: 'pending' | 'processing' | 'ready' | 'rejected'
}

const requests: Request[] = [
  {
    id: '1',
    type: 'Certificat de scolarité',
    date: '08 Jan 2025',
    status: 'ready',
  },
  {
    id: '2',
    type: 'Relevé de notes S3',
    date: '05 Jan 2025',
    status: 'processing',
  },
  {
    id: '3',
    type: "Attestation d'inscription",
    date: '02 Jan 2025',
    status: 'pending',
  },
]

const statusConfig = {
  pending: {
    label: 'En attente',
    color: 'bg-slate-100 text-slate-600',
    icon: Clock,
  },
  processing: {
    label: 'En traitement',
    color: 'bg-blue-100 text-blue-600',
    icon: Clock,
  },
  ready: {
    label: 'Prêt',
    color: 'bg-green-100 text-green-600',
    icon: CheckCircle,
  },
  rejected: {
    label: 'Rejeté',
    color: 'bg-red-100 text-red-600',
    icon: XCircle,
  },
}

export function StudentRequestsCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#3d5a80]/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-[#3d5a80]" />
            </div>
            <h2 className="text-lg font-semibold text-slate-900">
              Mes Demandes
            </h2>
          </div>
          <Button size="sm" className="bg-[#1e3a5f] hover:bg-[#0f2744]">
            <Plus className="w-4 h-4 mr-1" />
            Nouvelle
          </Button>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {requests.map((request, index) => {
          const StatusIcon = statusConfig[request.status].icon

          return (
            <motion.div
              key={request.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.5 + index * 0.05 }}
              className="p-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-slate-900">{request.type}</h3>
                  <p className="text-sm text-slate-500">
                    Demandé le {request.date}
                  </p>
                </div>
                <div
                  className={cn(
                    'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
                    statusConfig[request.status].color,
                  )}
                >
                  <StatusIcon className="w-3.5 h-3.5" />
                  <span>{statusConfig[request.status].label}</span>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100">
        <button className="w-full text-center text-sm text-[#1e3a5f] font-medium hover:underline">
          Voir toutes mes demandes →
        </button>
      </div>
    </motion.div>
  )
}
