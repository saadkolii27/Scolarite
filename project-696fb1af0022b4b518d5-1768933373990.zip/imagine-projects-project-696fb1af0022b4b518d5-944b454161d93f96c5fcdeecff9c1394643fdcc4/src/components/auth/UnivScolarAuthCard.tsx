import * as React from 'react'
import { Link } from '@tanstack/react-router'
import { GraduationCap } from 'lucide-react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'

interface UnivScolarAuthCardProps {
  title: string
  description: string
  children: React.ReactNode
  variant?: 'admin' | 'student'
}

export function UnivScolarAuthCard({
  title,
  description,
  children,
  variant = 'admin',
}: UnivScolarAuthCardProps) {
  return (
    <div className="min-h-screen w-full flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#0f2744] via-[#1e3a5f] to-[#2d4a6f] relative overflow-hidden">
        {/* Pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
        {/* Gradient Orbs */}
        <div className="absolute top-20 right-20 w-96 h-96 bg-[#c9a227]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-[#3d5a80]/20 rounded-full blur-3xl" />

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-white">
                UNIV-SCOLAR
              </h1>
              <p className="text-white/50 text-sm">Gestion Universitaire</p>
            </div>
          </Link>

          <div className="max-w-md">
            <h2 className="font-display text-4xl font-bold text-white mb-4">
              {variant === 'admin'
                ? 'Espace Administrateur'
                : 'Espace Étudiant'}
            </h2>
            <p className="text-white/70 text-lg leading-relaxed">
              {variant === 'admin'
                ? "Accédez à l'ensemble des fonctionnalités de gestion : scolarité, examens, notes et paramétrage."
                : 'Consultez vos notes, suivez vos demandes et accédez à toutes les informations de votre parcours académique.'}
            </p>
          </div>

          <div className="flex items-center gap-2 text-white/50 text-sm">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span>Système sécurisé</span>
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1e3a5f] to-[#3d5a80] flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span className="font-display text-xl font-bold text-[#1e3a5f]">
              UNIV-SCOLAR
            </span>
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-xl md:text-2xl font-display text-[#0f2744]">
                {title}
              </CardTitle>
              <CardDescription className="text-sm md:text-base text-slate-500">
                {description}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">{children}</CardContent>
          </Card>

          <p className="text-center text-xs text-slate-400 mt-6">
            © 2025 UNIV-SCOLAR. Tous droits réservés.
          </p>
        </div>
      </div>
    </div>
  )
}
