import { useState } from 'react'
import { Link, useLocation } from '@tanstack/react-router'
import { motion, AnimatePresence } from 'motion/react'
import {
  Home,
  Bell,
  Calendar,
  FileText,
  GraduationCap,
  BarChart3,
  MessageSquare,
  ChevronDown,
  BookOpen,
  LogOut,
  Menu,
  X,
  User,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'

interface CurrentStudent {
  $id: string
  cne: string
  cin: string | null
  apogeeCode: string | null
  firstName: string
  lastName: string
  firstNameAr: string | null
  lastNameAr: string | null
  email: string | null
  phone: string | null
  birthDate: string | null
  birthPlace: string | null
  gender: string | null
  nationality: string | null
  address: string | null
  filiereId: string | null
  etapeId: string | null
  academicYearId: string | null
  registrationDate: string | null
  status: string | null
  bacYear: number | null
  bacSeries: string | null
  bacMention: string | null
  photoFileId: string | null
  fullName: string
  fullNameAr: string | null
}

interface NavItem {
  label: string
  icon: React.ElementType
  href?: string
  children?: NavItem[]
}

const navigationItems: NavItem[] = [
  {
    label: 'Accueil',
    icon: Home,
    href: '/student',
  },
  {
    label: 'Mes Notes',
    icon: BarChart3,
    href: '/student/notes',
  },
  {
    label: 'Emploi du temps',
    icon: Calendar,
    href: '/student/emploi-du-temps',
  },
  {
    label: 'Avis & Annonces',
    icon: Bell,
    href: '/student/avis',
  },
  {
    label: 'Demandes de documents',
    icon: FileText,
    href: '/student/demandes',
  },
  {
    label: 'Réclamations',
    icon: MessageSquare,
    href: '/student/reclamations',
  },
  {
    label: 'Mon parcours',
    icon: BookOpen,
    href: '/student/parcours',
  },
  {
    label: 'Mon profil',
    icon: User,
    href: '/student/profil',
  },
]

interface NavItemComponentProps {
  item: NavItem
  depth?: number
}

function NavItemComponent({ item, depth = 0 }: NavItemComponentProps) {
  const [isOpen, setIsOpen] = useState(false)
  const location = useLocation()
  const hasChildren = item.children && item.children.length > 0
  const isActive = item.href === location.pathname

  const paddingLeft = depth * 12 + 12

  if (hasChildren) {
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            'w-full flex items-center justify-between py-2.5 px-3 rounded-lg text-sm transition-all duration-200',
            'hover:bg-[#1e3a5f]/10',
            isOpen ? 'bg-[#1e3a5f]/10 text-[#1e3a5f]' : 'text-slate-600',
          )}
          style={{ paddingLeft }}
        >
          <div className="flex items-center gap-3">
            <item.icon
              className={cn(
                'w-4 h-4 flex-shrink-0',
                isOpen ? 'text-[#1e3a5f]' : 'text-slate-400',
              )}
            />
            <span className="truncate">{item.label}</span>
          </div>
          <ChevronDown
            className={cn(
              'w-4 h-4 transition-transform duration-200',
              isOpen ? 'rotate-180' : '',
            )}
          />
        </button>
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="py-1">
                {item.children?.map((child, index) => (
                  <NavItemComponent
                    key={index}
                    item={child}
                    depth={depth + 1}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <Link
      to={item.href || '#'}
      className={cn(
        'flex items-center gap-3 py-2.5 px-3 rounded-lg text-sm transition-all duration-200',
        'hover:bg-[#1e3a5f]/10',
        isActive
          ? 'bg-[#1e3a5f] text-white font-medium'
          : 'text-slate-600 hover:text-[#1e3a5f]',
      )}
      style={{ paddingLeft }}
    >
      <item.icon
        className={cn(
          'w-4 h-4 flex-shrink-0',
          isActive ? 'text-white' : 'text-slate-400',
        )}
      />
      <span className="truncate">{item.label}</span>
    </Link>
  )
}

interface StudentSidebarProps {
  isOpen: boolean
  onToggle: () => void
  currentStudent?: CurrentStudent | null
}

export function StudentSidebar({
  isOpen,
  onToggle,
  currentStudent,
}: StudentSidebarProps) {
  const initials = currentStudent
    ? `${currentStudent.firstName.charAt(0)}${currentStudent.lastName.charAt(0)}`.toUpperCase()
    : 'ET'
  const fullName = currentStudent?.fullName || 'Étudiant'
  const cne = currentStudent?.cne || 'N/A'
  const apogeeCode = currentStudent?.apogeeCode || 'N/A'

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={onToggle}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-full bg-white border-r border-slate-200 z-50 transition-all duration-300',
          'lg:translate-x-0',
          isOpen
            ? 'translate-x-0 w-64'
            : '-translate-x-full lg:translate-x-0 lg:w-64',
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1e3a5f] to-[#3d5a80] flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-display text-lg font-bold text-[#1e3a5f]">
                  UNIV-SCOLAR
                </h1>
                <p className="text-xs text-slate-500">Espace Étudiant</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-slate-500 hover:text-slate-700"
              onClick={onToggle}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Student Info Card */}
          <div className="p-4 border-b border-slate-200">
            <div className="bg-gradient-to-br from-[#1e3a5f]/5 to-[#3d5a80]/5 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-full bg-[#1e3a5f] flex items-center justify-center text-white font-bold text-lg">
                  {initials}
                </div>
                <div>
                  <p className="font-medium text-slate-900">{fullName}</p>
                  <p className="text-xs text-slate-500">CNE: {cne}</p>
                </div>
              </div>
              <div className="text-xs text-slate-600 space-y-1">
                <p>
                  <span className="font-medium">Code Apogée:</span> {apogeeCode}
                </p>
                {currentStudent?.status && (
                  <p>
                    <span className="font-medium">Statut:</span>{' '}
                    <span
                      className={
                        currentStudent.status === 'active'
                          ? 'text-green-600'
                          : 'text-amber-600'
                      }
                    >
                      {currentStudent.status === 'active'
                        ? 'Actif'
                        : currentStudent.status}
                    </span>
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 py-4">
            <nav className="px-3 space-y-1">
              {navigationItems.map((item, index) => (
                <NavItemComponent key={index} item={item} />
              ))}
            </nav>
          </ScrollArea>

          {/* Footer */}
          <div className="p-4 border-t border-slate-200">
            <Link to="/student-sign-out">
              <Button
                variant="ghost"
                className="w-full justify-start text-slate-600 hover:text-red-600 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Déconnexion
              </Button>
            </Link>
          </div>
        </div>
      </aside>
    </>
  )
}

export function StudentMobileHeader({ onToggle }: { onToggle: () => void }) {
  return (
    <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-30 flex items-center px-4">
      <Button
        variant="ghost"
        size="icon"
        className="text-slate-600"
        onClick={onToggle}
      >
        <Menu className="w-6 h-6" />
      </Button>
      <div className="flex items-center gap-2 ml-4">
        <GraduationCap className="w-6 h-6 text-[#1e3a5f]" />
        <span className="font-display font-bold text-[#1e3a5f]">
          UNIV-SCOLAR
        </span>
      </div>
    </header>
  )
}
