import { useState } from 'react'
import { Link, useLocation } from '@tanstack/react-router'
import { motion, AnimatePresence } from 'motion/react'
import {
  Home,
  Bell,
  Calendar,
  Users,
  FileText,
  GraduationCap,
  ClipboardList,
  BarChart3,
  RefreshCw,
  MessageSquare,
  Settings,
  ChevronDown,
  ChevronRight,
  BookOpen,
  Building2,
  Layers,
  FolderTree,
  Clock,
  DoorOpen,
  Eye,
  FileCheck,
  AlertTriangle,
  Search,
  Download,
  UserCheck,
  PieChart,
  MapPin,
  Briefcase,
  Shield,
  UserCog,
  Stamp,
  UserPlus,
  LogOut,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import type { AdminRole } from '@/server/functions/admin-auth'

interface CurrentAdmin {
  $id: string
  email: string
  firstName: string
  lastName: string
  role: AdminRole
  roleLabel: string
  permissions: string[] | null
  departmentId: string | null
  isActive: boolean
  phone: string | null
  dbId: string
}

interface NavItem {
  label: string
  icon: React.ElementType
  href?: string
  children?: NavItem[]
}

const navigationItems: NavItem[] = [
  {
    label: 'Accueil',
    icon: Home,
    href: '/admin',
  },
  {
    label: 'Avis & Emplois du temps',
    icon: Bell,
    children: [
      { label: 'Avis', icon: Bell, href: '/admin/avis' },
      {
        label: 'Emploi du temps',
        icon: Calendar,
        href: '/admin/emploi-du-temps',
      },
    ],
  },
  {
    label: 'Scolarité',
    icon: GraduationCap,
    children: [
      {
        label: 'Demandes de document',
        icon: FileText,
        href: '/admin/scolarite/demandes',
      },
      {
        label: 'Retraits de Bac',
        icon: FileCheck,
        href: '/admin/scolarite/retraits-bac',
      },
      {
        label: 'Recherche des étudiants',
        icon: Search,
        href: '/admin/scolarite/recherche',
      },
      {
        label: 'Check nombre de modules',
        icon: ClipboardList,
        href: '/admin/scolarite/check-modules',
      },
      {
        label: 'Édition de documents',
        icon: FileText,
        href: '/admin/scolarite/edition',
      },
    ],
  },
  {
    label: 'Examens',
    icon: ClipboardList,
    children: [
      { label: 'Séances examens', icon: Clock, href: '/admin/examens/seances' },
      {
        label: 'Télécharger planification',
        icon: Download,
        href: '/admin/examens/planification',
      },
      {
        label: 'Affectation des étudiants',
        icon: UserCheck,
        href: '/admin/examens/affectation-etudiants',
      },
      { label: 'Reporting', icon: PieChart, href: '/admin/examens/reporting' },
      {
        label: 'Paramètres affichage - Notes',
        icon: Eye,
        href: '/admin/examens/params-affichage',
      },
      {
        label: 'Pointage de présence',
        icon: UserCheck,
        href: '/admin/examens/pointage',
      },
      {
        label: 'Affectation des places',
        icon: MapPin,
        href: '/admin/examens/affectation-places',
      },
    ],
  },
  {
    label: 'Résultats',
    icon: BarChart3,
    children: [
      {
        label: 'Tableau de bord - Notes',
        icon: BarChart3,
        href: '/admin/resultats/dashboard',
      },
      {
        label: 'Gestion des notes',
        icon: FileText,
        href: '/admin/resultats/notes',
      },
      {
        label: 'Réclamations - Notes',
        icon: MessageSquare,
        href: '/admin/resultats/reclamations',
      },
      {
        label: 'Synchronisation des notes',
        icon: RefreshCw,
        href: '/admin/resultats/sync',
      },
      {
        label: 'Type de résultats',
        icon: Layers,
        href: '/admin/resultats/types',
      },
      {
        label: 'Sanctions',
        icon: AlertTriangle,
        href: '/admin/resultats/sanctions',
      },
      {
        label: 'Traitements arrière-plan',
        icon: Clock,
        href: '/admin/resultats/traitements',
      },
      {
        label: 'Recherche étudiants - Notes',
        icon: Search,
        href: '/admin/resultats/recherche',
      },
    ],
  },
  {
    label: 'Synchronisation Apogée',
    icon: RefreshCw,
    children: [
      {
        label: 'Sync. des étudiants',
        icon: Users,
        href: '/admin/apogee/etudiants',
      },
      {
        label: 'Sync. des ensembles',
        icon: Layers,
        href: '/admin/apogee/ensembles',
      },
      {
        label: 'Sync. individuelle',
        icon: UserCheck,
        href: '/admin/apogee/individuelle',
      },
      {
        label: 'Sync. ELP - Convocation',
        icon: FileText,
        href: '/admin/apogee/elp-convocation',
      },
      {
        label: 'Tâches en arrière-plan',
        icon: Clock,
        href: '/admin/apogee/taches',
      },
    ],
  },
  {
    label: 'Réclamations',
    icon: MessageSquare,
    href: '/admin/reclamations',
  },
  {
    label: 'Paramétrages',
    icon: Settings,
    children: [
      {
        label: 'Année Universitaire',
        icon: Calendar,
        children: [
          {
            label: "Type d'élément",
            icon: Layers,
            href: '/admin/params/type-element',
          },
          {
            label: 'Année Universitaire',
            icon: Calendar,
            href: '/admin/params/annee-universitaire',
          },
        ],
      },
      { label: 'Session', icon: Clock, href: '/admin/params/session' },
      {
        label: 'Filières',
        icon: FolderTree,
        children: [
          {
            label: 'Département',
            icon: Building2,
            href: '/admin/params/departement',
          },
          { label: 'Cycle', icon: RefreshCw, href: '/admin/params/cycle' },
          {
            label: 'Type de composant',
            icon: Layers,
            href: '/admin/params/type-composant',
          },
          {
            label: 'Composant',
            icon: Briefcase,
            href: '/admin/params/composant',
          },
          { label: 'Étape', icon: ChevronRight, href: '/admin/params/etape' },
          { label: 'Filière', icon: FolderTree, href: '/admin/params/filiere' },
        ],
      },
      {
        label: 'Modules',
        icon: BookOpen,
        children: [
          {
            label: 'ELP Année',
            icon: Calendar,
            href: '/admin/params/elp-annee',
          },
          { label: 'Semestre', icon: Clock, href: '/admin/params/semestre' },
          { label: 'Ensemble', icon: Layers, href: '/admin/params/ensemble' },
          { label: 'Module', icon: BookOpen, href: '/admin/params/module' },
          {
            label: 'Élément de Module',
            icon: FileText,
            href: '/admin/params/element-module',
          },
        ],
      },
      {
        label: 'Planning Examen',
        icon: Calendar,
        children: [
          { label: 'Planning', icon: Calendar, href: '/admin/params/planning' },
          { label: 'Salles', icon: DoorOpen, href: '/admin/params/salles' },
          {
            label: 'Paramètres semestre IE',
            icon: Settings,
            href: '/admin/params/semestre-ie',
          },
        ],
      },
      {
        label: 'Affichage des notes',
        icon: Eye,
        children: [
          {
            label: 'Paramètres',
            icon: Settings,
            href: '/admin/params/affichage-notes',
          },
        ],
      },
      {
        label: 'Demandes',
        icon: FileText,
        children: [
          {
            label: 'Type de document',
            icon: FileText,
            href: '/admin/params/type-document',
          },
          {
            label: 'État de demande',
            icon: ClipboardList,
            href: '/admin/params/etat-demande',
          },
        ],
      },
      {
        label: 'Retrait de bac',
        icon: FileCheck,
        children: [
          {
            label: 'Type retrait de bac',
            icon: Layers,
            href: '/admin/params/type-retrait-bac',
          },
          {
            label: 'États',
            icon: ClipboardList,
            href: '/admin/params/etats-retrait',
          },
        ],
      },
      {
        label: 'Réclamations',
        icon: MessageSquare,
        children: [
          {
            label: 'Type réclamation',
            icon: Layers,
            href: '/admin/params/type-reclamation',
          },
        ],
      },
      {
        label: 'Utilisateurs',
        icon: Users,
        children: [
          {
            label: 'Administrateur',
            icon: Shield,
            href: '/admin/params/utilisateurs/admin',
          },
          {
            label: 'Scolarité',
            icon: GraduationCap,
            href: '/admin/params/utilisateurs/scolarite',
          },
          {
            label: 'Examen',
            icon: ClipboardList,
            href: '/admin/params/utilisateurs/examen',
          },
          {
            label: 'Gestionnaire des notes',
            icon: BarChart3,
            href: '/admin/params/utilisateurs/gestionnaire-notes',
          },
          {
            label: 'Signataire',
            icon: Stamp,
            href: '/admin/params/utilisateurs/signataire',
          },
          {
            label: 'Coordonnateur',
            icon: UserCog,
            href: '/admin/params/utilisateurs/coordonnateur',
          },
          {
            label: 'Surveillant',
            icon: Eye,
            href: '/admin/params/utilisateurs/surveillant',
          },
          {
            label: 'Coordonnateur Étape',
            icon: UserPlus,
            href: '/admin/params/utilisateurs/coordonnateur-etape',
          },
        ],
      },
    ],
  },
]

interface NavItemComponentProps {
  item: NavItem
  depth?: number
  isCollapsed?: boolean
}

function NavItemComponent({
  item,
  depth = 0,
  isCollapsed = false,
}: NavItemComponentProps) {
  const [isOpen, setIsOpen] = useState(false)
  const location = useLocation()
  const hasChildren = item.children && item.children.length > 0
  const isActive = item.href === location.pathname
  const isChildActive = item.children?.some(
    (child) =>
      child.href === location.pathname ||
      child.children?.some((subChild) => subChild.href === location.pathname),
  )

  const paddingLeft = depth * 12 + 12

  if (hasChildren) {
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            'w-full flex items-center justify-between py-2.5 px-3 rounded-lg text-sm transition-all duration-200',
            'hover:bg-white/10',
            isOpen || isChildActive
              ? 'bg-white/10 text-white'
              : 'text-white/70',
          )}
          style={{ paddingLeft }}
        >
          <div className="flex items-center gap-3">
            <item.icon
              className={cn(
                'w-4 h-4 flex-shrink-0',
                isOpen || isChildActive ? 'text-[#c9a227]' : 'text-white/50',
              )}
            />
            {!isCollapsed && <span className="truncate">{item.label}</span>}
          </div>
          {!isCollapsed && (
            <ChevronDown
              className={cn(
                'w-4 h-4 transition-transform duration-200',
                isOpen ? 'rotate-180' : '',
              )}
            />
          )}
        </button>
        <AnimatePresence>
          {isOpen && !isCollapsed && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="py-1">
                {item.children?.map((child, index) => (
                  <NavItemComponent
                    key={index}
                    item={child}
                    depth={depth + 1}
                    isCollapsed={isCollapsed}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    )
  }

  return (
    <Link
      to={item.href || '#'}
      className={cn(
        'flex items-center gap-3 py-2.5 px-3 rounded-lg text-sm transition-all duration-200',
        'hover:bg-white/10',
        isActive
          ? 'bg-[#c9a227]/20 text-[#c9a227] font-medium'
          : 'text-white/70 hover:text-white',
      )}
      style={{ paddingLeft }}
    >
      <item.icon
        className={cn(
          'w-4 h-4 flex-shrink-0',
          isActive ? 'text-[#c9a227]' : 'text-white/50',
        )}
      />
      {!isCollapsed && <span className="truncate">{item.label}</span>}
    </Link>
  )
}

interface AdminSidebarProps {
  isOpen: boolean
  onToggle: () => void
  currentAdmin?: CurrentAdmin | null
}

export function AdminSidebar({
  isOpen,
  onToggle,
  currentAdmin,
}: AdminSidebarProps) {
  const initials = currentAdmin
    ? `${currentAdmin.firstName.charAt(0)}${currentAdmin.lastName.charAt(0)}`.toUpperCase()
    : 'AD'
  const fullName = currentAdmin
    ? `${currentAdmin.firstName} ${currentAdmin.lastName}`
    : 'Administrateur'
  const email = currentAdmin?.email || 'admin@univ.ma'
  const roleLabel = currentAdmin?.roleLabel || 'Administrateur'

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={onToggle}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-full bg-gradient-to-b from-[#0f2744] to-[#1e3a5f] z-50 transition-all duration-300',
          'lg:translate-x-0',
          isOpen
            ? 'translate-x-0 w-72'
            : '-translate-x-full lg:translate-x-0 lg:w-72',
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-display text-lg font-bold text-white">
                  UNIV-SCOLAR
                </h1>
                <p className="text-xs text-white/50">Administration</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-white/70 hover:text-white hover:bg-white/10"
              onClick={onToggle}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 py-4">
            <nav className="px-3 space-y-1">
              {navigationItems.map((item, index) => (
                <NavItemComponent key={index} item={item} />
              ))}
            </nav>
          </ScrollArea>

          {/* Footer */}
          <div className="p-4 border-t border-white/10">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center text-white font-bold text-sm">
                {initials}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">
                  {fullName}
                </p>
                <p className="text-xs text-white/50 truncate">{email}</p>
              </div>
            </div>
            <div className="mb-3 px-1">
              <span className="inline-flex items-center px-2 py-1 rounded-md bg-[#c9a227]/20 text-[#c9a227] text-xs font-medium">
                {roleLabel}
              </span>
            </div>
            <Link to="/admin-sign-out">
              <Button
                variant="ghost"
                className="w-full justify-start text-white/70 hover:text-white hover:bg-white/10"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Déconnexion
              </Button>
            </Link>
          </div>
        </div>
      </aside>
    </>
  )
}

export function AdminMobileHeader({ onToggle }: { onToggle: () => void }) {
  return (
    <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-[#0f2744] border-b border-white/10 z-30 flex items-center px-4">
      <Button
        variant="ghost"
        size="icon"
        className="text-white/70 hover:text-white hover:bg-white/10"
        onClick={onToggle}
      >
        <Menu className="w-6 h-6" />
      </Button>
      <div className="flex items-center gap-2 ml-4">
        <GraduationCap className="w-6 h-6 text-[#c9a227]" />
        <span className="font-display font-bold text-white">UNIV-SCOLAR</span>
      </div>
    </header>
  )
}
