import { motion } from 'motion/react'
import {
  Users,
  FileText,
  Calendar,
  BarChart3,
  RefreshCw,
  Bell,
  ClipboardCheck,
  Shield,
  Database,
  Settings,
  BookOpen,
  Award,
} from 'lucide-react'

const features = [
  {
    icon: Users,
    title: 'Gestion de la Scolarité',
    description:
      'Suivi complet des étudiants, inscriptions, demandes de documents et retraits de bac.',
    color: '#1e3a5f',
  },
  {
    icon: Calendar,
    title: 'Organisation des Examens',
    description:
      'Planification des séances, affectation des salles, gestion des surveillants et pointage.',
    color: '#3d5a80',
  },
  {
    icon: BarChart3,
    title: 'Gestion des Notes',
    description:
      'Saisie, validation, publication des notes et génération des relevés de notes.',
    color: '#c9a227',
  },
  {
    icon: RefreshCw,
    title: 'Synchronisation Apogée',
    description:
      'Import/export automatisé des données étudiants, ensembles et éléments pédagogiques.',
    color: '#2a9d8f',
  },
  {
    icon: Bell,
    title: 'Avis & Emplois du temps',
    description:
      'Publication des annonces, gestion des emplois du temps par filière et étape.',
    color: '#e76f51',
  },
  {
    icon: ClipboardCheck,
    title: 'Réclamations',
    description:
      'Traitement des réclamations notes et demandes générales avec suivi en temps réel.',
    color: '#9c6644',
  },
  {
    icon: FileText,
    title: 'Documents Administratifs',
    description:
      'Génération automatique des attestations, certificats et relevés officiels.',
    color: '#457b9d',
  },
  {
    icon: Shield,
    title: 'Sécurité & Permissions',
    description:
      "Système de rôles granulaire avec contrôle d'accès par module et fonctionnalité.",
    color: '#6d597a',
  },
  {
    icon: Database,
    title: 'Paramétrage Complet',
    description:
      'Configuration des filières, modules, sessions, types de documents et états.',
    color: '#355070',
  },
  {
    icon: Settings,
    title: 'Tâches en Arrière-plan',
    description:
      'Traitements automatisés pour les calculs de moyennes et synchronisations.',
    color: '#b56576',
  },
  {
    icon: BookOpen,
    title: 'Suivi Académique',
    description:
      'Historique complet du parcours étudiant avec validation des modules.',
    color: '#4a5759',
  },
  {
    icon: Award,
    title: 'Résultats & Sanctions',
    description:
      'Gestion des délibérations, types de résultats et sanctions disciplinaires.',
    color: '#7f5539',
  },
]

export function FeaturesSection() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-[#c9a227]/10 text-[#c9a227] text-sm font-semibold rounded-full mb-4">
            FONCTIONNALITÉS
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-[#0f2744] mb-4">
            Une solution complète
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Tous les outils nécessaires pour une gestion universitaire efficace
            et moderne
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className="group relative bg-slate-50 rounded-2xl p-6 hover:bg-white hover:shadow-xl transition-all duration-300 border border-transparent hover:border-slate-200"
            >
              {/* Icon */}
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                style={{ backgroundColor: `${feature.color}15` }}
              >
                <feature.icon
                  className="w-6 h-6"
                  style={{ color: feature.color }}
                />
              </div>

              {/* Content */}
              <h3 className="font-semibold text-[#0f2744] mb-2 group-hover:text-[#1e3a5f] transition-colors">
                {feature.title}
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Indicator */}
              <div
                className="absolute bottom-0 left-6 right-6 h-0.5 rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"
                style={{ backgroundColor: feature.color }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
