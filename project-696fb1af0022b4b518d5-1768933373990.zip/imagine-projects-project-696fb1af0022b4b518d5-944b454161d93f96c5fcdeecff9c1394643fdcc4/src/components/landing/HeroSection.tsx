import { motion } from 'motion/react'
import { GraduationCap, Shield, Building2 } from 'lucide-react'

export function HeroSection() {
  return (
    <section className="relative min-h-[85vh] flex items-center overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f2744] via-[#1e3a5f] to-[#2d4a6f]">
        {/* Geometric Pattern Overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
        {/* Gradient Orbs */}
        <div className="absolute top-20 right-20 w-96 h-96 bg-[#c9a227]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-[#3d5a80]/20 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Text */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-8"
            >
              <div className="w-2 h-2 bg-[#c9a227] rounded-full animate-pulse" />
              <span className="text-white/90 text-sm font-medium tracking-wide">
                Plateforme Officielle de Gestion Universitaire
              </span>
            </motion.div>

            {/* Main Title */}
            <h1 className="font-display text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-[1.1] mb-6">
              <span className="block">UNIV</span>
              <span className="block text-[#c9a227]">SCOLAR</span>
            </h1>

            <p className="text-xl lg:text-2xl text-white/80 font-light leading-relaxed mb-8 max-w-xl">
              Système intégré de gestion de la scolarité, des examens et des
              résultats académiques
            </p>

            {/* Features List */}
            <div className="space-y-4 mb-10">
              {[
                {
                  icon: GraduationCap,
                  text: 'Gestion complète de la scolarité',
                },
                {
                  icon: Shield,
                  text: 'Sécurité et confidentialité des données',
                },
                { icon: Building2, text: 'Synchronisation avec Apogée' },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.5 }}
                  className="flex items-center gap-3 text-white/70"
                >
                  <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-[#c9a227]" />
                  </div>
                  <span className="text-lg">{item.text}</span>
                </motion.div>
              ))}
            </div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.5 }}
              className="flex gap-8 pt-8 border-t border-white/10"
            >
              {[
                { value: '15+', label: 'Modules' },
                { value: '100%', label: 'Sécurisé' },
                { value: '24/7', label: 'Disponible' },
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-[#c9a227]">
                    {stat.value}
                  </div>
                  <div className="text-sm text-white/60 mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right Column - Visual Element */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8, ease: 'easeOut' }}
            className="hidden lg:block"
          >
            <div className="relative">
              {/* Main Card */}
              <div className="relative bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 p-8 shadow-2xl">
                {/* Header */}
                <div className="flex items-center gap-4 mb-8 pb-6 border-b border-white/10">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center">
                    <GraduationCap className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">
                      Tableau de Bord
                    </h3>
                    <p className="text-white/50 text-sm">
                      Vue d'ensemble administrative
                    </p>
                  </div>
                </div>

                {/* Mock Dashboard Content */}
                <div className="space-y-4">
                  {/* Stats Row */}
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: 'Étudiants', value: '2,847' },
                      { label: 'Examens', value: '156' },
                      { label: 'Notes', value: '12,450' },
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="bg-white/5 rounded-xl p-4 text-center"
                      >
                        <div className="text-2xl font-bold text-white">
                          {item.value}
                        </div>
                        <div className="text-xs text-white/50 mt-1">
                          {item.label}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Progress Bars */}
                  <div className="space-y-3 pt-4">
                    {[
                      {
                        label: 'Inscriptions validées',
                        progress: 85,
                        color: '#c9a227',
                      },
                      {
                        label: 'Notes saisies',
                        progress: 72,
                        color: '#3d5a80',
                      },
                      {
                        label: 'Réclamations traitées',
                        progress: 94,
                        color: '#2a9d8f',
                      },
                    ].map((item, i) => (
                      <div key={i}>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-white/70">{item.label}</span>
                          <span className="text-white/90 font-medium">
                            {item.progress}%
                          </span>
                        </div>
                        <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${item.progress}%` }}
                            transition={{
                              delay: 1 + i * 0.2,
                              duration: 1,
                              ease: 'easeOut',
                            }}
                            className="h-full rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
                className="absolute -top-6 -right-6 bg-[#c9a227] rounded-2xl p-4 shadow-xl"
              >
                <Shield className="w-8 h-8 text-white" />
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{
                  duration: 5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
                className="absolute -bottom-4 -left-4 bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-white text-sm font-medium">
                    Système actif
                  </span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full"
        >
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="#f8fafc"
          />
        </svg>
      </div>
    </section>
  )
}
