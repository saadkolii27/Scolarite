import { motion } from 'motion/react'
import { Link } from '@tanstack/react-router'
import {
  ShieldCheck,
  GraduationCap,
  ArrowRight,
  Users,
  FileText,
  BarChart3,
  Calendar,
  BookOpen,
  ClipboardList,
  Bell,
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const adminFeatures = [
  { icon: Users, label: 'Gestion des utilisateurs' },
  { icon: FileText, label: 'Documents administratifs' },
  { icon: BarChart3, label: 'Tableaux de bord' },
  { icon: Calendar, label: 'Planning examens' },
]

const studentFeatures = [
  { icon: BookOpen, label: 'Consultation des notes' },
  { icon: ClipboardList, label: 'Demandes de documents' },
  { icon: Bell, label: 'Avis et annonces' },
  { icon: Calendar, label: 'Emploi du temps' },
]

export function AccessCards() {
  return (
    <section className="py-24 bg-[#f8fafc]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 bg-[#1e3a5f]/10 text-[#1e3a5f] text-sm font-semibold rounded-full mb-4">
            ACCÈS À LA PLATEFORME
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-[#0f2744] mb-4">
            Choisissez votre espace
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Connectez-vous à l'espace correspondant à votre profil pour accéder
            aux fonctionnalités adaptées
          </p>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Admin Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="group relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-[#1e3a5f] to-[#0f2744] rounded-3xl transform group-hover:scale-[1.02] transition-transform duration-300" />
            <div className="relative bg-gradient-to-br from-[#1e3a5f] to-[#0f2744] rounded-3xl p-8 lg:p-10 overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#c9a227]/10 rounded-full translate-y-1/2 -translate-x-1/2" />

              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center mb-6 shadow-lg">
                  <ShieldCheck className="w-8 h-8 text-white" />
                </div>

                {/* Title */}
                <h3 className="font-display text-2xl lg:text-3xl font-bold text-white mb-3">
                  Espace Administrateur
                </h3>
                <p className="text-white/70 mb-8 leading-relaxed">
                  Accès complet à toutes les fonctionnalités de gestion :
                  scolarité, examens, notes, paramétrage et synchronisation
                  Apogée.
                </p>

                {/* Features */}
                <div className="grid grid-cols-2 gap-3 mb-8">
                  {adminFeatures.map((feature, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 text-white/80"
                    >
                      <feature.icon className="w-4 h-4 text-[#c9a227]" />
                      <span className="text-sm">{feature.label}</span>
                    </div>
                  ))}
                </div>

                {/* Button */}
                <Link to="/admin-login">
                  <Button
                    size="lg"
                    className="w-full bg-white text-[#1e3a5f] hover:bg-white/90 font-semibold group/btn"
                  >
                    <span>Connexion Administrateur</span>
                    <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                {/* Roles Info */}
                <p className="text-white/50 text-xs mt-4 text-center">
                  Administration • Scolarité • Examens • Gestionnaires
                </p>
              </div>
            </div>
          </motion.div>

          {/* Student Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="group relative"
          >
            <div className="absolute inset-0 bg-white rounded-3xl shadow-xl transform group-hover:scale-[1.02] transition-transform duration-300" />
            <div className="relative bg-white rounded-3xl p-8 lg:p-10 border-2 border-slate-100 overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#1e3a5f]/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#c9a227]/5 rounded-full translate-y-1/2 -translate-x-1/2" />

              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#3d5a80] to-[#2d4a6f] flex items-center justify-center mb-6 shadow-lg">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>

                {/* Title */}
                <h3 className="font-display text-2xl lg:text-3xl font-bold text-[#0f2744] mb-3">
                  Espace Étudiant
                </h3>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  Consultez vos notes, suivez vos demandes de documents, accédez
                  aux avis et emplois du temps.
                </p>

                {/* Features */}
                <div className="grid grid-cols-2 gap-3 mb-8">
                  {studentFeatures.map((feature, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 text-slate-600"
                    >
                      <feature.icon className="w-4 h-4 text-[#3d5a80]" />
                      <span className="text-sm">{feature.label}</span>
                    </div>
                  ))}
                </div>

                {/* Button */}
                <Link to="/student-login">
                  <Button
                    size="lg"
                    className="w-full bg-[#1e3a5f] text-white hover:bg-[#0f2744] font-semibold group/btn"
                  >
                    <span>Connexion Étudiant</span>
                    <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                {/* Info */}
                <p className="text-slate-400 text-xs mt-4 text-center">
                  Utilisez votre Code Apogée et CIN pour vous connecter
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
