import { GraduationCap, Mail, Phone, MapPin, Settings } from 'lucide-react'
import { Link } from '@tanstack/react-router'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-[#0f2744] text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#c9a227] to-[#a88420] flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-display text-2xl font-bold">UNIV-SCOLAR</h3>
                <p className="text-white/50 text-sm">Gestion Universitaire</p>
              </div>
            </div>
            <p className="text-white/70 leading-relaxed max-w-md mb-6">
              Plateforme intégrée de gestion de la scolarité, des examens et des
              résultats académiques. Solution sécurisée et évolutive pour les
              établissements d'enseignement supérieur.
            </p>
            <div className="flex items-center gap-2 text-white/50 text-sm">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span>Système opérationnel</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-6">Liens Rapides</h4>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/admin-login"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  Espace Administrateur
                </Link>
              </li>
              <li>
                <Link
                  to="/student-login"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  Espace Étudiant
                </Link>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  Documentation
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  Support Technique
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white mb-6">Contact</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#c9a227] mt-0.5 flex-shrink-0" />
                <span className="text-white/60 text-sm">
                  Faculté des Sciences
                  <br />
                  Université Mohammed V<br />
                  Rabat, Maroc
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#c9a227] flex-shrink-0" />
                <a
                  href="mailto:scolarite@univ.ma"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  scolarite@univ.ma
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#c9a227] flex-shrink-0" />
                <a
                  href="tel:+212537000000"
                  className="text-white/60 hover:text-[#c9a227] transition-colors text-sm"
                >
                  +212 5 37 00 00 00
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/50 text-sm">
              © {currentYear} UNIV-SCOLAR. Tous droits réservés.
            </p>
            <div className="flex items-center gap-6">
              <a
                href="#"
                className="text-white/50 hover:text-white/80 text-sm transition-colors"
              >
                Mentions légales
              </a>
              <a
                href="#"
                className="text-white/50 hover:text-white/80 text-sm transition-colors"
              >
                Politique de confidentialité
              </a>
              <Link
                to="/init-accounts"
                className="text-white/30 hover:text-amber-400/80 text-sm transition-colors flex items-center gap-1"
              >
                <Settings className="w-3 h-3" />
                Configuration
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
