import { createServerFn } from '@tanstack/react-start'
import z from 'zod'
import { redirect } from '@tanstack/react-router'
import { Query } from 'node-appwrite'
import {
  deleteCookie,
  getCookie,
  setCookie,
  setResponseStatus,
} from '@tanstack/react-start/server'
import { db } from '../lib/db'
import type { Students } from '../lib/appwrite.types'

// Student session data stored in cookie (encrypted/signed by the framework)
interface StudentSession {
  studentId: string
  apogeeCode: string
  cin: string
  timestamp: number
}

// Session duration: 24 hours
const SESSION_DURATION = 60 * 60 * 24

// Get student session from cookie
export const getStudentSessionFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const sessionData = getCookie('student-session')
    if (!sessionData) return null

    try {
      // Parse the session data
      const session = JSON.parse(sessionData) as StudentSession

      // Check if session is expired
      const now = Date.now()
      const sessionAge = (now - session.timestamp) / 1000

      if (sessionAge > SESSION_DURATION) {
        // Session expired
        return null
      }

      return session
    } catch {
      return null
    }
  },
)

// Set student session cookie
export const setStudentSessionCookieFn = createServerFn({ method: 'POST' })
  .inputValidator(
    z.object({
      studentId: z.string(),
      apogeeCode: z.string(),
      cin: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const sessionData: StudentSession = {
      studentId: data.studentId,
      apogeeCode: data.apogeeCode,
      cin: data.cin,
      timestamp: Date.now(),
    }

    setCookie('student-session', JSON.stringify(sessionData), {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: SESSION_DURATION,
    })

    setCookie('user-type', 'student', {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: SESSION_DURATION,
    })
  })

// Student sign in schema - Code Apogée + CIN
const studentSignInSchema = z.object({
  apogeeCode: z
    .string()
    .min(1, 'Le code Apogée est requis')
    .regex(/^[0-9]+$/, 'Le code Apogée doit contenir uniquement des chiffres'),
  cin: z
    .string()
    .min(1, 'Le CIN est requis')
    .transform((val) => val.toUpperCase().trim()),
  redirect: z.string().optional(),
})

// Student sign in function
export const studentSignInFn = createServerFn({ method: 'POST' })
  .inputValidator(studentSignInSchema)
  .handler(async ({ data }) => {
    const { apogeeCode, cin, redirect: redirectUrl } = data

    // Normalize inputs
    const normalizedApogeeCode = apogeeCode.trim()
    const normalizedCin = cin.toUpperCase().trim()

    try {
      // Step 1: Find student by Apogee code
      const studentsResult = await db.students.list([
        Query.equal('apogeeCode', [normalizedApogeeCode]),
      ])

      let student: Students | null = null

      if (studentsResult.total > 0) {
        student = studentsResult.rows[0] as Students
      } else {
        // Try to find by CNE as fallback (some students might use CNE)
        const byCneResult = await db.students.list([
          Query.equal('cne', [normalizedApogeeCode]),
        ])

        if (byCneResult.total > 0) {
          student = byCneResult.rows[0] as Students
        }
      }

      if (!student) {
        setResponseStatus(401)
        throw {
          message:
            'Code Apogée non trouvé. Vérifiez vos informations ou contactez le service scolarité.',
          status: 401,
        }
      }

      // Step 2: Verify CIN matches (case-insensitive, trimmed)
      const studentCin = student.cin?.toUpperCase().trim()

      if (!studentCin) {
        setResponseStatus(401)
        throw {
          message:
            "Votre CIN n'est pas enregistré dans le système. Contactez le service scolarité.",
          status: 401,
        }
      }

      if (studentCin !== normalizedCin) {
        setResponseStatus(401)
        throw {
          message:
            'CIN incorrect. Vérifiez vos informations ou contactez le service scolarité.',
          status: 401,
        }
      }

      // Step 3: Check student status
      const inactiveStatuses = [
        'inactive',
        'suspended',
        'expelled',
        'graduated',
      ]

      if (
        student.status &&
        inactiveStatuses.includes(student.status.toLowerCase())
      ) {
        let statusMessage = 'Votre compte étudiant est inactif.'

        switch (student.status.toLowerCase()) {
          case 'suspended':
            statusMessage = 'Votre compte étudiant est suspendu.'
            break
          case 'expelled':
            statusMessage = 'Votre compte étudiant a été révoqué.'
            break
          case 'graduated':
            statusMessage =
              "Vous avez terminé votre cursus. Votre accès étudiant n'est plus actif."
            break
        }

        setResponseStatus(403)
        throw {
          message: `${statusMessage} Contactez le service scolarité pour plus d'informations.`,
          status: 403,
        }
      }

      // Step 4: Create student session
      await setStudentSessionCookieFn({
        data: {
          studentId: student.$id,
          apogeeCode: student.apogeeCode || normalizedApogeeCode,
          cin: studentCin,
        },
      })

      // Success - redirect to student dashboard
      throw redirect({ to: redirectUrl || '/student' })
    } catch (_error) {
      const error = _error as { message?: string; status?: number; to?: string }

      // If it's a redirect, rethrow it
      if (error.to) {
        throw error
      }

      // If it's our custom error with status, rethrow it
      if (error.status) {
        throw error
      }

      // Unexpected error
      console.error('Unexpected student auth error:', error)
      setResponseStatus(500)
      throw {
        message: 'Une erreur est survenue. Veuillez réessayer.',
        status: 500,
      }
    }
  })

// Student sign out function
export const studentSignOutFn = createServerFn({ method: 'POST' }).handler(
  async () => {
    deleteCookie('student-session')
    deleteCookie('user-type')
  },
)

// Get current student with full info
export const getCurrentStudentFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const session = await getStudentSessionFn()

    if (!session) {
      return null
    }

    try {
      // Get student record from database
      const student = await db.students.get(session.studentId)

      if (!student) {
        return null
      }

      // Verify session data still matches (security check)
      const studentCin = student.cin?.toUpperCase().trim()
      const sessionCin = session.cin.toUpperCase().trim()

      if (studentCin !== sessionCin) {
        // Session data doesn't match current student data
        // This could indicate tampering or data change
        return null
      }

      // Check if student is still active
      const inactiveStatuses = ['inactive', 'suspended', 'expelled']
      if (
        student.status &&
        inactiveStatuses.includes(student.status.toLowerCase())
      ) {
        return null
      }

      return {
        $id: student.$id,
        cne: student.cne,
        cin: student.cin,
        apogeeCode: student.apogeeCode,
        firstName: student.firstName,
        lastName: student.lastName,
        firstNameAr: student.firstNameAr,
        lastNameAr: student.lastNameAr,
        email: student.email,
        phone: student.phone,
        birthDate: student.birthDate,
        birthPlace: student.birthPlace,
        gender: student.gender,
        nationality: student.nationality,
        address: student.address,
        filiereId: student.filiereId,
        etapeId: student.etapeId,
        academicYearId: student.academicYearId,
        registrationDate: student.registrationDate,
        status: student.status,
        bacYear: student.bacYear,
        bacSeries: student.bacSeries,
        bacMention: student.bacMention,
        photoFileId: student.photoFileId,
        fullName: `${student.firstName} ${student.lastName}`,
        fullNameAr:
          student.firstNameAr && student.lastNameAr
            ? `${student.firstNameAr} ${student.lastNameAr}`
            : null,
      }
    } catch (error) {
      console.warn('Error getting current student:', error)
      return null
    }
  },
)

// Student auth middleware
export const studentAuthMiddleware = createServerFn({ method: 'GET' }).handler(
  async () => {
    const currentStudent = await getCurrentStudentFn()
    return { currentStudent }
  },
)

// Get user type from cookie
export const getUserTypeFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const userType = getCookie('user-type')
    return userType as 'admin' | 'student' | null
  },
)

// Refresh student session (extend expiration)
export const refreshStudentSessionFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const session = await getStudentSessionFn()

  if (!session) {
    return { success: false, reason: 'no_session' }
  }

  // Refresh the session with new timestamp
  await setStudentSessionCookieFn({
    data: {
      studentId: session.studentId,
      apogeeCode: session.apogeeCode,
      cin: session.cin,
    },
  })

  return { success: true }
})
