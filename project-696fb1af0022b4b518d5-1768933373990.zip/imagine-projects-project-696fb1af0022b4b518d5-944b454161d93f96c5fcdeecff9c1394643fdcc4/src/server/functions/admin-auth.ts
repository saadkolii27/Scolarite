import { createServerFn } from '@tanstack/react-start'
import z from 'zod'
import { redirect } from '@tanstack/react-router'
import { createAdminClient, createSessionClient } from '../lib/appwrite'
import { AppwriteException, Query } from 'node-appwrite'
import {
  deleteCookie,
  getCookie,
  setCookie,
  setResponseStatus,
} from '@tanstack/react-start/server'
import { db } from '../lib/db'
import type { Users } from '../lib/appwrite.types'

// Admin roles in the system
export const ADMIN_ROLES = [
  'super_admin',
  'admin',
  'scolarite',
  'examens',
  'gestionnaire_notes',
  'stagiaire',
  'coordonnateur',
  'surveillant',
  'coordonnateur_etape',
] as const

export type AdminRole = (typeof ADMIN_ROLES)[number]

// Role labels in French
export const ROLE_LABELS: Record<AdminRole, string> = {
  super_admin: 'Super Administrateur',
  admin: 'Administrateur',
  scolarite: 'Service Scolarité',
  examens: 'Service Examens',
  gestionnaire_notes: 'Gestionnaire des Notes',
  stagiaire: 'Stagiaire',
  coordonnateur: 'Coordonnateur',
  surveillant: 'Surveillant',
  coordonnateur_etape: "Coordonnateur d'Étape",
}

// Get session from cookie
export const getAdminSessionFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const session = getCookie('appwrite-session-secret')
    if (!session) return null
    return session
  },
)

// Set session cookies
export const setAdminSessionCookiesFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ id: z.string(), secret: z.string() }))
  .handler(async ({ data }) => {
    const { id, secret } = data
    setCookie('appwrite-session-secret', secret, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
    })
    setCookie('appwrite-session-id', id, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
    })
    setCookie('user-type', 'admin', {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
    })
  })

// Admin sign in schema
const adminSignInSchema = z.object({
  email: z.string().email('Veuillez entrer une adresse email valide'),
  password: z.string().min(1, 'Le mot de passe est requis'),
  redirect: z.string().optional(),
})

/**
 * Find user in database by email (case-insensitive)
 */
async function findUserByEmail(email: string): Promise<Users | null> {
  const normalizedEmail = email.toLowerCase().trim()

  // Try exact match first
  const exactMatch = await db.users.list([Query.equal('email', [email])])
  if (exactMatch.total > 0) {
    return exactMatch.rows[0] as Users
  }

  // Try case-insensitive search
  const allUsers = await db.users.list([])
  const found = allUsers.rows.find(
    (u) => u.email.toLowerCase() === normalizedEmail,
  )

  return (found as Users) || null
}

// Admin sign in function
export const adminSignInFn = createServerFn({ method: 'POST' })
  .inputValidator(adminSignInSchema)
  .handler(async ({ data }) => {
    const { email, password, redirect: redirectUrl } = data

    try {
      // Step 1: Find user in our database
      const userRecord = await findUserByEmail(email)

      if (!userRecord) {
        setResponseStatus(401)
        throw {
          message:
            "Aucun compte administrateur trouvé avec cet email. Vérifiez l'adresse email ou contactez le service informatique.",
          status: 401,
          code: 'USER_NOT_FOUND',
        }
      }

      // Step 2: Check if user is active
      if (!userRecord.isActive) {
        setResponseStatus(403)
        throw {
          message:
            'Votre compte a été désactivé. Contactez un administrateur pour le réactiver.',
          status: 403,
          code: 'ACCOUNT_DISABLED',
        }
      }

      // Step 3: Check if user has a valid admin role
      if (!ADMIN_ROLES.includes(userRecord.role as AdminRole)) {
        setResponseStatus(403)
        throw {
          message:
            "Vous n'avez pas les permissions nécessaires pour accéder à l'espace administrateur.",
          status: 403,
          code: 'INSUFFICIENT_ROLE',
        }
      }

      // Step 4: Authenticate with Appwrite
      const { account } = createAdminClient()

      let session
      try {
        // Use the email from the database record to ensure consistency
        session = await account.createEmailPasswordSession(
          userRecord.email,
          password,
        )
      } catch (_error) {
        const appwriteError = _error as AppwriteException
        console.error(
          'Appwrite auth error:',
          appwriteError.code,
          appwriteError.message,
          appwriteError.type,
        )

        // Handle specific Appwrite errors
        if (
          appwriteError.code === 401 ||
          appwriteError.type === 'user_invalid_credentials'
        ) {
          setResponseStatus(401)
          throw {
            message:
              'Mot de passe incorrect. Veuillez vérifier votre mot de passe et réessayer.',
            status: 401,
            code: 'INVALID_PASSWORD',
          }
        }

        if (
          appwriteError.code === 404 ||
          appwriteError.type === 'user_not_found'
        ) {
          // User exists in DB but not in Appwrite Auth
          // This means the account needs to be synchronized
          setResponseStatus(401)
          throw {
            message:
              "Votre compte n'est pas encore synchronisé avec le système d'authentification. Veuillez contacter le service informatique ou utiliser la page de configuration initiale (/setup).",
            status: 401,
            code: 'AUTH_NOT_SYNCED',
          }
        }

        if (appwriteError.code === 429) {
          setResponseStatus(429)
          throw {
            message:
              'Trop de tentatives de connexion. Veuillez patienter quelques minutes avant de réessayer.',
            status: 429,
            code: 'RATE_LIMITED',
          }
        }

        if (
          appwriteError.type === 'user_blocked' ||
          appwriteError.code === 403
        ) {
          setResponseStatus(403)
          throw {
            message: 'Votre compte a été bloqué. Contactez un administrateur.',
            status: 403,
            code: 'USER_BLOCKED',
          }
        }

        // Generic authentication error
        console.error('Unexpected Appwrite error:', appwriteError)
        setResponseStatus(401)
        throw {
          message:
            "Erreur d'authentification. Veuillez vérifier vos identifiants et réessayer.",
          status: 401,
          code: 'AUTH_ERROR',
        }
      }

      // Step 5: Verify the authenticated user matches our database record
      try {
        const client = await createSessionClient(session.secret)
        const appwriteUser = await client.account.get()

        // Verify email matches (case-insensitive)
        if (
          appwriteUser.email.toLowerCase() !== userRecord.email.toLowerCase()
        ) {
          console.error(
            'Email mismatch:',
            appwriteUser.email,
            'vs',
            userRecord.email,
          )
          await account.deleteSession(session.$id)
          setResponseStatus(403)
          throw {
            message:
              'Erreur de synchronisation du compte. Les emails ne correspondent pas. Contactez le service informatique.',
            status: 403,
            code: 'EMAIL_MISMATCH',
          }
        }
      } catch (verifyError) {
        // If it's our custom error, rethrow it
        if ((verifyError as { code?: string }).code === 'EMAIL_MISMATCH') {
          throw verifyError
        }
        // Otherwise, log warning but continue (session is valid)
        console.warn('Session verification warning:', verifyError)
      }

      // Step 6: Set session cookies
      await setAdminSessionCookiesFn({
        data: { id: session.$id, secret: session.secret },
      })

      // Success - redirect to admin dashboard
      throw redirect({ to: redirectUrl || '/admin' })
    } catch (_error) {
      const error = _error as AppwriteException & {
        message?: string
        status?: number
        code?: string
        to?: string // redirect property
      }

      // If it's a redirect, rethrow it
      if (error.to) {
        throw error
      }

      // If it's our custom error with status, rethrow it
      if (error.status && error.code) {
        throw error
      }

      // Unexpected error
      console.error('Unexpected auth error:', error)
      setResponseStatus(500)
      throw {
        message:
          'Une erreur inattendue est survenue. Veuillez réessayer plus tard.',
        status: 500,
        code: 'UNEXPECTED_ERROR',
      }
    }
  })

// Sign out function
export const adminSignOutFn = createServerFn({ method: 'POST' }).handler(
  async () => {
    const sessionSecret = getCookie('appwrite-session-secret')
    const sessionId = getCookie('appwrite-session-id')

    // Try to delete the Appwrite session
    if (sessionSecret && sessionId) {
      try {
        const { account } = createAdminClient()
        await account.deleteSession(sessionId)
      } catch (error) {
        // Session might already be expired, continue with cookie cleanup
        console.warn('Could not delete Appwrite session:', error)
      }
    }

    // Always clear cookies
    deleteCookie('appwrite-session-secret')
    deleteCookie('appwrite-session-id')
    deleteCookie('user-type')
  },
)

// Get current admin user with role info
export const getCurrentAdminFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    const session = await getAdminSessionFn()

    if (!session) {
      return null
    }

    try {
      const client = await createSessionClient(session)
      const appwriteUser = await client.account.get()

      // Get user record from our database
      const userRecord = await findUserByEmail(appwriteUser.email)

      if (!userRecord) {
        console.warn(
          'User authenticated but not found in DB:',
          appwriteUser.email,
        )
        return null
      }

      // Verify user is still active
      if (!userRecord.isActive) {
        console.warn('User authenticated but account is disabled')
        return null
      }

      // Verify user has admin role
      if (!ADMIN_ROLES.includes(userRecord.role as AdminRole)) {
        console.warn(
          'User authenticated but does not have admin role:',
          userRecord.role,
        )
        return null
      }

      return {
        $id: appwriteUser.$id,
        email: appwriteUser.email,
        firstName: userRecord.firstName,
        lastName: userRecord.lastName,
        role: userRecord.role as AdminRole,
        roleLabel: ROLE_LABELS[userRecord.role as AdminRole] || userRecord.role,
        permissions: userRecord.permissions,
        departmentId: userRecord.departmentId,
        isActive: userRecord.isActive,
        phone: userRecord.phone,
        dbId: userRecord.$id,
      }
    } catch (error) {
      console.warn('Error getting current admin:', error)
      return null
    }
  },
)

// Admin auth middleware
export const adminAuthMiddleware = createServerFn({ method: 'GET' }).handler(
  async () => {
    const currentAdmin = await getCurrentAdminFn()
    return { currentAdmin }
  },
)

// Check if admin has specific permission
export const checkAdminPermissionFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ permission: z.string() }))
  .handler(async ({ data }) => {
    const currentAdmin = await getCurrentAdminFn()

    if (!currentAdmin) {
      return { hasPermission: false, reason: 'not_authenticated' }
    }

    // Super admin has all permissions
    if (currentAdmin.role === 'super_admin') {
      return { hasPermission: true }
    }

    // Check wildcard permission
    if (currentAdmin.permissions?.includes('*')) {
      return { hasPermission: true }
    }

    // Check specific permission
    if (currentAdmin.permissions?.includes(data.permission)) {
      return { hasPermission: true }
    }

    return { hasPermission: false, reason: 'insufficient_permissions' }
  })
