import { createServerFn } from '@tanstack/react-start'
import { createAdminClient } from '../lib/appwrite'
import {
  AppwriteException,
  ID,
  Query,
  Users,
  Permission,
  Role,
  Client,
  TablesDB,
} from 'node-appwrite'
import { db } from '../lib/db'
import { z } from 'zod'
import { ADMIN_ROLES, type AdminRole } from './admin-auth'
import type { Students } from '../lib/appwrite.types'

// ============================================================================
// ADMIN ACCOUNT CREATION
// ============================================================================

const createAdminSchema = z.object({
  email: z.string().email('Email invalide'),
  password: z
    .string()
    .min(8, 'Le mot de passe doit contenir au moins 8 caractères'),
  firstName: z.string().min(1, 'Le prénom est requis'),
  lastName: z.string().min(1, 'Le nom est requis'),
  role: z.enum(ADMIN_ROLES as unknown as [string, ...string[]]),
  phone: z.string().nullable().optional(),
  departmentId: z.string().nullable().optional(),
})

/**
 * Create a new admin account
 * Creates both the Appwrite Auth user and the database record
 */
export const createAdminAccountFn = createServerFn({ method: 'POST' })
  .inputValidator(createAdminSchema)
  .handler(async ({ data }) => {
    const { client } = createAdminClient()
    const users = new Users(client)

    const normalizedEmail = data.email.toLowerCase().trim()

    try {
      // Step 1: Check if user already exists in database
      const existingDbUsers = await db.users.list([
        Query.equal('email', [normalizedEmail]),
      ])

      if (existingDbUsers.total > 0) {
        return {
          success: false,
          message:
            'Un compte avec cet email existe déjà dans la base de données.',
          code: 'EMAIL_EXISTS_DB',
        }
      }

      // Also check case-insensitive
      const allDbUsers = await db.users.list([])
      const existingByEmail = allDbUsers.rows.find(
        (u) => u.email.toLowerCase() === normalizedEmail,
      )

      if (existingByEmail) {
        return {
          success: false,
          message:
            'Un compte avec cet email existe déjà dans la base de données.',
          code: 'EMAIL_EXISTS_DB',
        }
      }

      // Step 2: Check if user exists in Appwrite Auth
      let appwriteUserId: string | null = null

      try {
        const appwriteUsersList = await users.list([
          Query.equal('email', [normalizedEmail]),
        ])

        if (appwriteUsersList.total > 0) {
          // User exists in Appwrite, use their ID
          appwriteUserId = appwriteUsersList.users[0].$id
          console.log('User already exists in Appwrite Auth:', appwriteUserId)

          // Update their password to the new one
          await users.updatePassword(appwriteUserId, data.password)
        }
      } catch (error) {
        console.warn('Error checking Appwrite users:', error)
      }

      // Step 3: Create Appwrite Auth user if not exists
      if (!appwriteUserId) {
        try {
          const newUser = await users.create(
            ID.unique(),
            normalizedEmail,
            undefined, // phone
            data.password,
            `${data.firstName} ${data.lastName}`,
          )
          appwriteUserId = newUser.$id
          console.log('Created new Appwrite user:', appwriteUserId)

          // Verify email automatically
          await users.updateEmailVerification(appwriteUserId, true)
        } catch (_error) {
          const error = _error as AppwriteException

          if (error.code === 409) {
            // User already exists (race condition)
            const retryList = await users.list([
              Query.equal('email', [normalizedEmail]),
            ])
            if (retryList.total > 0) {
              appwriteUserId = retryList.users[0].$id
              await users.updatePassword(appwriteUserId, data.password)
            } else {
              throw new Error(
                "Impossible de créer l'utilisateur Appwrite: " + error.message,
              )
            }
          } else {
            throw error
          }
        }
      }

      if (!appwriteUserId) {
        throw new Error("Impossible d'obtenir l'ID utilisateur Appwrite")
      }

      // Step 4: Create database record
      const dbUser = await db.users.create({
        createdBy: appwriteUserId,
        email: normalizedEmail,
        firstName: data.firstName.trim(),
        lastName: data.lastName.trim(),
        role: data.role,
        permissions: data.role === 'super_admin' ? ['*'] : null,
        departmentId: data.departmentId || null,
        isActive: true,
        phone: data.phone || null,
      })

      console.log('Created DB record for admin:', dbUser.$id)

      return {
        success: true,
        message: `Compte administrateur créé avec succès pour ${data.firstName} ${data.lastName}.`,
        user: {
          dbId: dbUser.$id,
          appwriteId: appwriteUserId,
          email: normalizedEmail,
          firstName: data.firstName,
          lastName: data.lastName,
          role: data.role,
        },
        credentials: {
          email: normalizedEmail,
          password: data.password,
        },
      }
    } catch (_error) {
      const error = _error as Error
      console.error('Error creating admin account:', error)

      return {
        success: false,
        message:
          error.message ||
          'Erreur lors de la création du compte administrateur.',
        code: 'CREATE_ERROR',
      }
    }
  })

// ============================================================================
// STUDENT ACCOUNT CREATION
// ============================================================================

const createStudentSchema = z.object({
  cne: z.string().min(1, 'Le CNE est requis'),
  cin: z
    .string()
    .min(1, 'Le CIN est requis')
    .transform((val) => val.toUpperCase().trim()),
  apogeeCode: z.string().min(1, 'Le code Apogée est requis'),
  firstName: z.string().min(1, 'Le prénom est requis'),
  lastName: z.string().min(1, 'Le nom est requis'),
  firstNameAr: z.string().nullable().optional(),
  lastNameAr: z.string().nullable().optional(),
  email: z.string().email('Email invalide').nullable().optional(),
  phone: z.string().nullable().optional(),
  birthDate: z.string().nullable().optional(),
  birthPlace: z.string().nullable().optional(),
  gender: z.enum(['M', 'F']).nullable().optional(),
  nationality: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  filiereId: z.string().nullable().optional(),
  etapeId: z.string().nullable().optional(),
  academicYearId: z.string().nullable().optional(),
  registrationDate: z.string().nullable().optional(),
  status: z.string().default('active'),
  bacYear: z.number().nullable().optional(),
  bacSeries: z.string().nullable().optional(),
  bacMention: z.string().nullable().optional(),
})

/**
 * Create a new student account using direct TablesDB with custom permissions
 * Students don't use Appwrite Auth - they authenticate with Apogee Code + CIN
 */
export const createStudentAccountFn = createServerFn({ method: 'POST' })
  .inputValidator(createStudentSchema)
  .handler(async ({ data }) => {
    try {
      const normalizedCne = data.cne.trim()
      const normalizedApogeeCode = data.apogeeCode.trim()
      const normalizedCin = data.cin.toUpperCase().trim()

      // Step 1: Check if student already exists by CNE
      const existingByCne = await db.students.list([
        Query.equal('cne', [normalizedCne]),
      ])

      if (existingByCne.total > 0) {
        return {
          success: false,
          message: 'Un étudiant avec ce CNE existe déjà.',
          code: 'CNE_EXISTS',
        }
      }

      // Step 2: Check if student exists by Apogee code
      const existingByApogee = await db.students.list([
        Query.equal('apogeeCode', [normalizedApogeeCode]),
      ])

      if (existingByApogee.total > 0) {
        return {
          success: false,
          message: 'Un étudiant avec ce code Apogée existe déjà.',
          code: 'APOGEE_EXISTS',
        }
      }

      // Step 3: Check if student exists by CIN
      const existingByCin = await db.students.list([
        Query.equal('cin', [normalizedCin]),
      ])

      if (existingByCin.total > 0) {
        return {
          success: false,
          message: 'Un étudiant avec ce CIN existe déjà.',
          code: 'CIN_EXISTS',
        }
      }

      // Step 4: Create student record using direct TablesDB with custom permissions
      // We use 'system-init' as createdBy but set permissions to allow any user to read
      const client = new Client()
        .setEndpoint(process.env.APPWRITE_ENDPOINT!)
        .setProject(process.env.APPWRITE_PROJECT_ID!)
        .setKey(process.env.APPWRITE_API_KEY!)

      const tablesDB = new TablesDB(client)

      const studentData: Omit<
        Students,
        | '$id'
        | '$createdAt'
        | '$updatedAt'
        | '$permissions'
        | '$databaseId'
        | '$collectionId'
      > = {
        createdBy: 'system-init',
        cne: normalizedCne,
        cin: normalizedCin,
        apogeeCode: normalizedApogeeCode,
        firstName: data.firstName.trim(),
        lastName: data.lastName.trim(),
        firstNameAr: data.firstNameAr?.trim() || null,
        lastNameAr: data.lastNameAr?.trim() || null,
        email: data.email?.toLowerCase().trim() || null,
        phone: data.phone?.trim() || null,
        birthDate: data.birthDate || null,
        birthPlace: data.birthPlace?.trim() || null,
        gender: data.gender || null,
        nationality: data.nationality?.trim() || null,
        address: data.address?.trim() || null,
        filiereId: data.filiereId || null,
        etapeId: data.etapeId || null,
        academicYearId: data.academicYearId || null,
        registrationDate: data.registrationDate || new Date().toISOString(),
        status: data.status || 'active',
        bacYear: data.bacYear || null,
        bacSeries: data.bacSeries?.trim() || null,
        bacMention: data.bacMention?.trim() || null,
        photoFileId: null,
      }

      const student = await tablesDB.createRow<Students>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        rowId: ID.unique(),
        data: studentData,
        permissions: [
          // Allow any authenticated user to read (for admin access)
          Permission.read(Role.any()),
          // Allow any authenticated user to update/delete (admin operations)
          Permission.update(Role.any()),
          Permission.delete(Role.any()),
        ],
      })

      console.log('Created student record:', student.$id)

      return {
        success: true,
        message: `Compte étudiant créé avec succès pour ${data.firstName} ${data.lastName}.`,
        student: {
          id: student.$id,
          cne: normalizedCne,
          cin: normalizedCin,
          apogeeCode: normalizedApogeeCode,
          firstName: data.firstName,
          lastName: data.lastName,
        },
        credentials: {
          apogeeCode: normalizedApogeeCode,
          cin: normalizedCin,
          note: "L'étudiant se connecte avec son Code Apogée et son CIN.",
        },
      }
    } catch (_error) {
      const error = _error as Error
      console.error('Error creating student account:', error)

      return {
        success: false,
        message:
          error.message || 'Erreur lors de la création du compte étudiant.',
        code: 'CREATE_ERROR',
      }
    }
  })

// ============================================================================
// LIST ACCOUNTS (for verification)
// ============================================================================

/**
 * List all admin accounts
 */
export const listAdminAccountsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    try {
      const admins = await db.users.list([])

      return {
        success: true,
        admins: admins.rows.map((admin) => ({
          id: admin.$id,
          email: admin.email,
          firstName: admin.firstName,
          lastName: admin.lastName,
          role: admin.role,
          isActive: admin.isActive,
          createdAt: admin.$createdAt,
        })),
        total: admins.total,
      }
    } catch (error) {
      console.error('Error listing admins:', error)
      return {
        success: false,
        admins: [],
        total: 0,
      }
    }
  },
)

/**
 * List all student accounts
 */
export const listStudentAccountsFn = createServerFn({ method: 'GET' }).handler(
  async () => {
    try {
      const students = await db.students.list([Query.limit(100)])

      return {
        success: true,
        students: students.rows.map((student) => ({
          id: student.$id,
          cne: student.cne,
          cin: student.cin,
          apogeeCode: student.apogeeCode,
          firstName: student.firstName,
          lastName: student.lastName,
          email: student.email,
          status: student.status,
          createdAt: student.$createdAt,
        })),
        total: students.total,
      }
    } catch (error) {
      console.error('Error listing students:', error)
      return {
        success: false,
        students: [],
        total: 0,
      }
    }
  },
)

// ============================================================================
// DELETE ACCOUNTS (for cleanup during testing)
// ============================================================================

/**
 * Delete an admin account
 */
export const deleteAdminAccountFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const { client } = createAdminClient()
    const users = new Users(client)

    try {
      // Get the admin record
      const admin = await db.users.get(data.id)

      if (!admin) {
        return {
          success: false,
          message: 'Compte administrateur non trouvé.',
        }
      }

      // Try to delete from Appwrite Auth
      try {
        // Find Appwrite user by email
        const appwriteUsers = await users.list([
          Query.equal('email', [admin.email]),
        ])

        if (appwriteUsers.total > 0) {
          await users.delete(appwriteUsers.users[0].$id)
          console.log('Deleted Appwrite user:', appwriteUsers.users[0].$id)
        }
      } catch (error) {
        console.warn('Could not delete Appwrite user:', error)
      }

      // Delete from database
      await db.users.delete(data.id)
      console.log('Deleted admin from DB:', data.id)

      return {
        success: true,
        message: `Compte administrateur ${admin.email} supprimé.`,
      }
    } catch (error) {
      console.error('Error deleting admin:', error)
      return {
        success: false,
        message: 'Erreur lors de la suppression du compte.',
      }
    }
  })

/**
 * Delete a student account
 */
export const deleteStudentAccountFn = createServerFn({ method: 'POST' })
  .inputValidator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    try {
      const student = await db.students.get(data.id)

      if (!student) {
        return {
          success: false,
          message: 'Compte étudiant non trouvé.',
        }
      }

      await db.students.delete(data.id)
      console.log('Deleted student from DB:', data.id)

      return {
        success: true,
        message: `Compte étudiant ${student.firstName} ${student.lastName} supprimé.`,
      }
    } catch (error) {
      console.error('Error deleting student:', error)
      return {
        success: false,
        message: 'Erreur lors de la suppression du compte.',
      }
    }
  })
