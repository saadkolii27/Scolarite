import { createServerFn } from '@tanstack/react-start'
import { createAdminClient } from '../lib/appwrite'
import { AppwriteException, ID, Query, Users } from 'node-appwrite'
import { db } from '../lib/db'

// Super Admin credentials - these must match what's in the database
const SUPER_ADMIN_EMAIL = 'Admin@admin.com'
const SUPER_ADMIN_PASSWORD = 'ADMIN12345'
const SUPER_ADMIN_FIRST_NAME = 'Super'
const SUPER_ADMIN_LAST_NAME = 'Administrateur'

/**
 * Check the complete status of Super Admin account
 * Checks both the database and Appwrite Auth
 */
export const checkSuperAdminExistsFn = createServerFn({
  method: 'GET',
}).handler(async () => {
  const { client } = createAdminClient()
  const users = new Users(client)

  let dbExists = false
  let authExists = false
  let dbUser = null
  let authUser = null

  // Check database
  try {
    // Try exact match first
    const existingDbUsers = await db.users.list([
      Query.equal('email', [SUPER_ADMIN_EMAIL]),
    ])

    // If not found, try case-insensitive search
    if (existingDbUsers.total === 0) {
      const allUsers = await db.users.list([])
      const found = allUsers.rows.find(
        (u) => u.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase(),
      )
      if (found) {
        dbUser = found
        dbExists = true
      }
    } else {
      dbUser = existingDbUsers.rows[0]
      dbExists = true
    }
  } catch (error) {
    console.error('Error checking DB:', error)
  }

  // Check Appwrite Auth
  try {
    const appwriteUsersList = await users.list([
      Query.equal('email', [SUPER_ADMIN_EMAIL]),
    ])

    // Also try case-insensitive
    if (appwriteUsersList.total === 0) {
      const allAppwriteUsers = await users.list([Query.limit(100)])
      const found = allAppwriteUsers.users.find(
        (u) => u.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase(),
      )
      if (found) {
        authUser = found
        authExists = true
      }
    } else {
      authUser = appwriteUsersList.users[0]
      authExists = true
    }
  } catch (error) {
    console.error('Error checking Appwrite Auth:', error)
  }

  // Determine status
  let status: 'configured' | 'db_only' | 'auth_only' | 'not_found'
  let message: string

  if (dbExists && authExists) {
    status = 'configured'
    message =
      'Le compte Super Admin est correctement configuré dans la base de données et Appwrite Auth.'
  } else if (dbExists && !authExists) {
    status = 'db_only'
    message =
      "Le compte existe dans la base de données mais pas dans Appwrite Auth. Cliquez sur 'Synchroniser' pour créer l'utilisateur dans Appwrite."
  } else if (!dbExists && authExists) {
    status = 'auth_only'
    message =
      "Le compte existe dans Appwrite Auth mais pas dans la base de données. Cliquez sur 'Synchroniser' pour créer l'enregistrement."
  } else {
    status = 'not_found'
    message =
      "Aucun compte Super Admin trouvé. Cliquez sur 'Synchroniser' pour créer le compte complet."
  }

  return {
    exists: dbExists && authExists,
    dbExists,
    authExists,
    email: SUPER_ADMIN_EMAIL,
    status,
    message,
    dbUserId: dbUser?.$id || null,
    authUserId: authUser?.$id || null,
  }
})

/**
 * Synchronize Super Admin from database to Appwrite Auth
 * This is the main function to fix authentication issues
 *
 * If user exists in DB but not in Auth: Creates Auth user
 * If user exists in Auth but not in DB: Creates DB record
 * If neither exists: Creates both
 * If both exist: Updates password to ensure sync
 */
export const syncSuperAdminFromDbFn = createServerFn({
  method: 'POST',
}).handler(async () => {
  const { client } = createAdminClient()
  const users = new Users(client)

  try {
    // Step 1: Check current status
    const status = await checkSuperAdminExistsFn()

    console.log('Current status:', status)

    let appwriteUserId: string | null = status.authUserId
    let dbUserId: string | null = status.dbUserId

    // Step 2: Handle Appwrite Auth user
    if (!status.authExists) {
      // Need to create Appwrite Auth user
      console.log('Creating Appwrite Auth user...')

      try {
        const newUser = await users.create(
          ID.unique(),
          SUPER_ADMIN_EMAIL,
          undefined, // phone
          SUPER_ADMIN_PASSWORD,
          `${SUPER_ADMIN_FIRST_NAME} ${SUPER_ADMIN_LAST_NAME}`,
        )
        appwriteUserId = newUser.$id
        console.log('Created Appwrite user:', appwriteUserId)

        // Verify email automatically
        await users.updateEmailVerification(appwriteUserId, true)
      } catch (_error) {
        const error = _error as AppwriteException
        console.error('Error creating Appwrite user:', error)

        if (error.code === 409) {
          // User already exists (race condition), find them
          const retryList = await users.list([
            Query.equal('email', [SUPER_ADMIN_EMAIL]),
          ])
          if (retryList.total > 0) {
            appwriteUserId = retryList.users[0].$id
          } else {
            throw new Error(
              "Impossible de créer l'utilisateur Appwrite: " + error.message,
            )
          }
        } else {
          throw error
        }
      }
    } else {
      // User exists in Auth, update password to ensure it matches
      console.log('Updating password for existing Appwrite user...')
      try {
        await users.updatePassword(appwriteUserId!, SUPER_ADMIN_PASSWORD)
        console.log('Password updated successfully')
      } catch (error) {
        console.warn('Could not update password:', error)
        // Continue anyway, password might already be correct
      }
    }

    if (!appwriteUserId) {
      throw new Error("Impossible d'obtenir l'ID utilisateur Appwrite")
    }

    // Step 3: Handle database record
    if (!status.dbExists) {
      // Need to create DB record
      console.log('Creating database record...')

      const newDbUser = await db.users.create({
        createdBy: appwriteUserId,
        email: SUPER_ADMIN_EMAIL,
        firstName: SUPER_ADMIN_FIRST_NAME,
        lastName: SUPER_ADMIN_LAST_NAME,
        role: 'super_admin',
        permissions: ['*'],
        departmentId: null,
        isActive: true,
        phone: null,
      })
      dbUserId = newDbUser.$id
      console.log('Created DB record:', dbUserId)
    } else {
      // DB record exists, ensure createdBy matches Appwrite user ID
      console.log('Checking DB record consistency...')

      // Get the current DB record
      const currentDbUser = await db.users.get(dbUserId!)

      if (currentDbUser.createdBy !== appwriteUserId) {
        console.log('Updating createdBy to match Appwrite user ID...')
        // We need to delete and recreate the record with correct createdBy
        // because createdBy is used for permissions
        await db.users.delete(dbUserId!)

        const newDbUser = await db.users.create({
          createdBy: appwriteUserId,
          email: currentDbUser.email,
          firstName: currentDbUser.firstName,
          lastName: currentDbUser.lastName,
          role: currentDbUser.role,
          permissions: currentDbUser.permissions,
          departmentId: currentDbUser.departmentId,
          isActive: currentDbUser.isActive,
          phone: currentDbUser.phone,
        })
        dbUserId = newDbUser.$id
        console.log('Recreated DB record with correct createdBy:', dbUserId)
      }
    }

    return {
      success: true,
      message:
        'Compte Super Administrateur synchronisé avec succès. Vous pouvez maintenant vous connecter.',
      appwriteUserId,
      dbUserId,
      credentials: {
        email: SUPER_ADMIN_EMAIL,
        password: SUPER_ADMIN_PASSWORD,
        note: 'Utilisez ces identifiants pour vous connecter.',
      },
    }
  } catch (_error) {
    const error = _error as AppwriteException & { message?: string }
    console.error('Error syncing super admin:', error)

    return {
      success: false,
      message:
        error.message ||
        'Erreur lors de la synchronisation du compte Super Administrateur.',
      error: true,
    }
  }
})

/**
 * Initialize the Super Admin account (legacy function)
 * Kept for backward compatibility
 */
export const initSuperAdminFn = createServerFn({ method: 'POST' }).handler(
  async () => {
    return await syncSuperAdminFromDbFn()
  },
)

/**
 * Repair Super Admin account - complete reset and recreation
 * Use this if sync doesn't work
 */
export const repairSuperAdminFn = createServerFn({ method: 'POST' }).handler(
  async () => {
    const { client } = createAdminClient()
    const users = new Users(client)

    try {
      console.log('Starting complete repair of Super Admin account...')

      // Step 1: Delete all existing DB records for this email
      try {
        const existingDbUsers = await db.users.list([])
        for (const user of existingDbUsers.rows) {
          if (user.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
            console.log('Deleting DB record:', user.$id)
            await db.users.delete(user.$id)
          }
        }
      } catch (error) {
        console.warn('Error cleaning DB records:', error)
      }

      // Step 2: Delete all existing Appwrite users for this email
      try {
        const appwriteUsersList = await users.list([Query.limit(100)])
        for (const user of appwriteUsersList.users) {
          if (user.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
            console.log('Deleting Appwrite user:', user.$id)
            await users.delete(user.$id)
          }
        }
      } catch (error) {
        console.warn('Error cleaning Appwrite users:', error)
      }

      // Step 3: Wait a moment for deletions to propagate
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Step 4: Create fresh account
      return await syncSuperAdminFromDbFn()
    } catch (_error) {
      const error = _error as Error
      console.error('Error repairing super admin:', error)
      return {
        success: false,
        message: error.message || 'Erreur lors de la réparation du compte.',
        error: true,
      }
    }
  },
)
