import { type Models } from 'node-appwrite'

export type Users = Models.Row & {
  createdBy: string
  email: string
  firstName: string
  lastName: string
  role: string
  permissions: string[] | null
  departmentId: string | null
  isActive: boolean
  phone: string | null
}

export type Students = Models.Row & {
  createdBy: string
  cne: string
  cin: string | null
  apogeeCode: string | null
  firstName: string
  lastName: string
  firstNameAr: string | null
  lastNameAr: string | null
  email: string | null
  phone: string | null
  birthDate: string | null
  birthPlace: string | null
  gender: string | null
  nationality: string | null
  address: string | null
  filiereId: string | null
  etapeId: string | null
  academicYearId: string | null
  registrationDate: string | null
  status: string | null
  bacYear: number | null
  bacSeries: string | null
  bacMention: string | null
  photoFileId: string | null
}

export type AcademicYears = Models.Row & {
  createdBy: string
  label: string
  startDate: string | null
  endDate: string | null
  isCurrent: boolean
}

export type Sessions = Models.Row & {
  createdBy: string
  label: string
  code: string
  academicYearId: string
  type: string | null
  startDate: string | null
  endDate: string | null
  isActive: boolean
}

export type Departments = Models.Row & {
  createdBy: string
  name: string
  code: string
  description: string | null
}

export type Cycles = Models.Row & {
  createdBy: string
  name: string
  code: string
  duration: number | null
}

export type ComponentTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
}

export type Components = Models.Row & {
  createdBy: string
  name: string
  code: string
  componentTypeId: string | null
  departmentId: string | null
}

export type Etapes = Models.Row & {
  createdBy: string
  name: string
  code: string
  filiereId: string
  level: number | null
  apogeeCode: string | null
}

export type Filieres = Models.Row & {
  createdBy: string
  name: string
  code: string
  cycleId: string | null
  componentId: string | null
  departmentId: string | null
  apogeeCode: string | null
  description: string | null
}

export type ElementTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
}

export type ElpYears = Models.Row & {
  createdBy: string
  name: string
  code: string
  filiereId: string | null
}

export type Semesters = Models.Row & {
  createdBy: string
  name: string
  code: string
  elpYearId: string | null
  etapeId: string | null
  order: number | null
}

export type Ensembles = Models.Row & {
  createdBy: string
  name: string
  code: string
  semesterId: string | null
  apogeeCode: string | null
  coefficient: number | null
}

export type Modules = Models.Row & {
  createdBy: string
  name: string
  code: string
  ensembleId: string | null
  semesterId: string | null
  apogeeCode: string | null
  coefficient: number | null
  credits: number | null
}

export type ModuleElements = Models.Row & {
  createdBy: string
  name: string
  code: string
  moduleId: string
  apogeeCode: string | null
  coefficient: number | null
  elementTypeId: string | null
}

export type ExamRooms = Models.Row & {
  createdBy: string
  name: string
  code: string
  capacity: number | null
  building: string | null
  floor: string | null
  isActive: boolean
}

export type ExamPlannings = Models.Row & {
  createdBy: string
  name: string
  sessionId: string
  academicYearId: string
  startDate: string | null
  endDate: string | null
  status: string | null
}

export type ExamSessions = Models.Row & {
  createdBy: string
  planningId: string
  moduleElementId: string | null
  moduleId: string | null
  examDate: string
  startTime: string
  endTime: string
  duration: number | null
  roomIds: string[] | null
  supervisorIds: string[] | null
  coordinatorId: string | null
  status: string | null
}

export type ExamStudentAssignments = Models.Row & {
  createdBy: string
  examSessionId: string
  studentId: string
  roomId: string | null
  seatNumber: string | null
  isPresent: boolean | null
  attendanceTime: string | null
  remarks: string | null
}

export type SemesterIeParams = Models.Row & {
  createdBy: string
  semesterId: string
  sessionId: string
  startDate: string | null
  endDate: string | null
  isActive: boolean
}

export type Grades = Models.Row & {
  createdBy: string
  studentId: string
  moduleElementId: string | null
  moduleId: string | null
  sessionId: string
  academicYearId: string
  grade: number | null
  gradeStatus: string | null
  isAbsent: boolean
  isFraud: boolean
  isPublished: boolean
  publishedAt: string | null
  enteredBy: string | null
  validatedBy: string | null
  validatedAt: string | null
}

export type ResultTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
  description: string | null
}

export type Sanctions = Models.Row & {
  createdBy: string
  studentId: string
  examSessionId: string | null
  type: string
  reason: string
  decision: string | null
  startDate: string | null
  endDate: string | null
  status: string | null
  decidedBy: string | null
}

export type GradeClaims = Models.Row & {
  createdBy: string
  studentId: string
  gradeId: string
  claimTypeId: string | null
  description: string
  status: string | null
  response: string | null
  processedBy: string | null
  processedAt: string | null
  newGrade: number | null
}

export type ClaimTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
}

export type GradeDisplayParams = Models.Row & {
  createdBy: string
  sessionId: string
  filiereId: string | null
  showGrades: boolean
  showRanking: boolean
  startDate: string | null
  endDate: string | null
}

export type ApogeeSyncLogs = Models.Row & {
  createdBy: string
  syncType: string
  status: string
  startedAt: string
  completedAt: string | null
  recordsProcessed: number | null
  recordsSuccess: number | null
  recordsFailed: number | null
  errorLog: string | null
  triggeredBy: string | null
}

export type BackgroundTasks = Models.Row & {
  createdBy: string
  taskType: string
  taskName: string
  status: string
  progress: number | null
  startedAt: string | null
  completedAt: string | null
  parameters: string | null
  result: string | null
  errorMessage: string | null
}

export type Announcements = Models.Row & {
  createdBy: string
  title: string
  content: string
  type: string | null
  targetAudience: string | null
  filiereIds: string[] | null
  etapeIds: string[] | null
  isPublished: boolean
  publishedAt: string | null
  expiresAt: string | null
  isPinned: boolean
  attachmentIds: string[] | null
}

export type Schedules = Models.Row & {
  createdBy: string
  title: string
  filiereId: string | null
  etapeId: string | null
  semesterId: string | null
  academicYearId: string | null
  fileId: string | null
  isActive: boolean
  validFrom: string | null
  validTo: string | null
}

export type DocumentTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
  description: string | null
  processingDays: number | null
  requiresApproval: boolean
}

export type RequestStatuses = Models.Row & {
  createdBy: string
  name: string
  code: string
  color: string | null
  order: number | null
}

export type DocumentRequests = Models.Row & {
  createdBy: string
  studentId: string
  documentTypeId: string
  statusId: string | null
  requestNumber: string | null
  quantity: number | null
  purpose: string | null
  notes: string | null
  processedBy: string | null
  processedAt: string | null
  deliveredAt: string | null
}

export type BacWithdrawalTypes = Models.Row & {
  createdBy: string
  name: string
  code: string
}

export type BacWithdrawalStatuses = Models.Row & {
  createdBy: string
  name: string
  code: string
  color: string | null
}

export type BacWithdrawals = Models.Row & {
  createdBy: string
  studentId: string
  withdrawalTypeId: string | null
  statusId: string | null
  requestDate: string | null
  withdrawalDate: string | null
  reason: string | null
  processedBy: string | null
  notes: string | null
}

export type Signatories = Models.Row & {
  createdBy: string
  userId: string
  title: string
  signatureFileId: string | null
  stampFileId: string | null
  isActive: boolean
  documentTypes: string[] | null
}

export type Coordinators = Models.Row & {
  createdBy: string
  userId: string
  filiereIds: string[] | null
  moduleIds: string[] | null
  isActive: boolean
}

export type EtapeCoordinators = Models.Row & {
  createdBy: string
  userId: string
  etapeIds: string[] | null
  isActive: boolean
}

export type Supervisors = Models.Row & {
  createdBy: string
  userId: string
  isAvailable: boolean
  maxSessionsPerDay: number | null
}

export type GeneralClaims = Models.Row & {
  createdBy: string
  studentId: string
  subject: string
  description: string
  category: string | null
  status: string | null
  response: string | null
  processedBy: string | null
  processedAt: string | null
  attachmentIds: string[] | null
}

export type AuditLogs = Models.Row & {
  createdBy: string
  userId: string
  action: string
  entityType: string
  entityId: string | null
  oldValue: string | null
  newValue: string | null
  ipAddress: string | null
  userAgent: string | null
}
