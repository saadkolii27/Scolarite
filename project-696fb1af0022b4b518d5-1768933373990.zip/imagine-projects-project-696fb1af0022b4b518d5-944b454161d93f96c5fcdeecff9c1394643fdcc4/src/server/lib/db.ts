import {
  Client,
  TablesDB,
  ID,
  type Models,
  Permission,
  Role,
} from 'node-appwrite'
import type {
  Users,
  Students,
  AcademicYears,
  Sessions,
  Departments,
  Cycles,
  ComponentTypes,
  Components,
  Etapes,
  Filieres,
  ElementTypes,
  ElpYears,
  Semesters,
  Ensembles,
  Modules,
  ModuleElements,
  ExamRooms,
  ExamPlannings,
  ExamSessions,
  ExamStudentAssignments,
  SemesterIeParams,
  Grades,
  ResultTypes,
  Sanctions,
  GradeClaims,
  ClaimTypes,
  GradeDisplayParams,
  ApogeeSyncLogs,
  BackgroundTasks,
  Announcements,
  Schedules,
  DocumentTypes,
  RequestStatuses,
  DocumentRequests,
  BacWithdrawalTypes,
  BacWithdrawalStatuses,
  BacWithdrawals,
  Signatories,
  Coordinators,
  EtapeCoordinators,
  Supervisors,
  GeneralClaims,
  AuditLogs,
} from './appwrite.types'

const client = new Client()
  .setEndpoint(process.env.APPWRITE_ENDPOINT!)
  .setProject(process.env.APPWRITE_PROJECT_ID!)
  .setKey(process.env.APPWRITE_API_KEY!)

const tablesDB = new TablesDB(client)

export const db = {
  users: {
    create: (
      data: Omit<Users, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Users>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'users',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Users>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'users',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Users, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Users>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'users',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'users',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Users>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'users',
        queries,
      }),
  },
  students: {
    create: (
      data: Omit<Students, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Students>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Students>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Students, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Students>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Students>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'students',
        queries,
      }),
  },
  academicYears: {
    create: (
      data: Omit<AcademicYears, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<AcademicYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'academic_years',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<AcademicYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'academic_years',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<AcademicYears, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<AcademicYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'academic_years',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'academic_years',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<AcademicYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'academic_years',
        queries,
      }),
  },
  sessions: {
    create: (
      data: Omit<Sessions, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Sessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sessions',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Sessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sessions',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Sessions, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Sessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sessions',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sessions',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Sessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sessions',
        queries,
      }),
  },
  departments: {
    create: (
      data: Omit<Departments, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Departments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'departments',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Departments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'departments',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Departments, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Departments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'departments',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'departments',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Departments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'departments',
        queries,
      }),
  },
  cycles: {
    create: (
      data: Omit<Cycles, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Cycles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'cycles',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Cycles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'cycles',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Cycles, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Cycles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'cycles',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'cycles',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Cycles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'cycles',
        queries,
      }),
  },
  componentTypes: {
    create: (
      data: Omit<ComponentTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ComponentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'component_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ComponentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'component_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ComponentTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ComponentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'component_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'component_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ComponentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'component_types',
        queries,
      }),
  },
  components: {
    create: (
      data: Omit<Components, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Components>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'components',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Components>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'components',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Components, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Components>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'components',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'components',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Components>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'components',
        queries,
      }),
  },
  etapes: {
    create: (
      data: Omit<Etapes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Etapes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etapes',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Etapes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etapes',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Etapes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Etapes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etapes',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etapes',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Etapes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etapes',
        queries,
      }),
  },
  filieres: {
    create: (
      data: Omit<Filieres, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Filieres>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'filieres',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Filieres>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'filieres',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Filieres, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Filieres>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'filieres',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'filieres',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Filieres>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'filieres',
        queries,
      }),
  },
  elementTypes: {
    create: (
      data: Omit<ElementTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ElementTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'element_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ElementTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'element_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ElementTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ElementTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'element_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'element_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ElementTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'element_types',
        queries,
      }),
  },
  elpYears: {
    create: (
      data: Omit<ElpYears, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ElpYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'elp_years',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ElpYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'elp_years',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ElpYears, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ElpYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'elp_years',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'elp_years',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ElpYears>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'elp_years',
        queries,
      }),
  },
  semesters: {
    create: (
      data: Omit<Semesters, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Semesters>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semesters',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Semesters>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semesters',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Semesters, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Semesters>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semesters',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semesters',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Semesters>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semesters',
        queries,
      }),
  },
  ensembles: {
    create: (
      data: Omit<Ensembles, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Ensembles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ensembles',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Ensembles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ensembles',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Ensembles, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Ensembles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ensembles',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ensembles',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Ensembles>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'ensembles',
        queries,
      }),
  },
  modules: {
    create: (
      data: Omit<Modules, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Modules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'modules',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Modules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'modules',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Modules, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Modules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'modules',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'modules',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Modules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'modules',
        queries,
      }),
  },
  moduleElements: {
    create: (
      data: Omit<ModuleElements, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ModuleElements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'module_elements',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ModuleElements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'module_elements',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ModuleElements, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ModuleElements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'module_elements',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'module_elements',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ModuleElements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'module_elements',
        queries,
      }),
  },
  examRooms: {
    create: (
      data: Omit<ExamRooms, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ExamRooms>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_rooms',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ExamRooms>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_rooms',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ExamRooms, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ExamRooms>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_rooms',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_rooms',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ExamRooms>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_rooms',
        queries,
      }),
  },
  examPlannings: {
    create: (
      data: Omit<ExamPlannings, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ExamPlannings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_plannings',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ExamPlannings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_plannings',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ExamPlannings, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ExamPlannings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_plannings',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_plannings',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ExamPlannings>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_plannings',
        queries,
      }),
  },
  examSessions: {
    create: (
      data: Omit<ExamSessions, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ExamSessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_sessions',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ExamSessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_sessions',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ExamSessions, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ExamSessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_sessions',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_sessions',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ExamSessions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_sessions',
        queries,
      }),
  },
  examStudentAssignments: {
    create: (
      data: Omit<ExamStudentAssignments, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ExamStudentAssignments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_student_assignments',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ExamStudentAssignments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_student_assignments',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ExamStudentAssignments, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ExamStudentAssignments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_student_assignments',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_student_assignments',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ExamStudentAssignments>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'exam_student_assignments',
        queries,
      }),
  },
  semesterIeParams: {
    create: (
      data: Omit<SemesterIeParams, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<SemesterIeParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semester_ie_params',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<SemesterIeParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semester_ie_params',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<SemesterIeParams, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<SemesterIeParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semester_ie_params',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semester_ie_params',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<SemesterIeParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'semester_ie_params',
        queries,
      }),
  },
  grades: {
    create: (
      data: Omit<Grades, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Grades>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grades',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Grades>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grades',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Grades, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Grades>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grades',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grades',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Grades>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grades',
        queries,
      }),
  },
  resultTypes: {
    create: (
      data: Omit<ResultTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ResultTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'result_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ResultTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'result_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ResultTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ResultTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'result_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'result_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ResultTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'result_types',
        queries,
      }),
  },
  sanctions: {
    create: (
      data: Omit<Sanctions, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Sanctions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sanctions',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Sanctions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sanctions',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Sanctions, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Sanctions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sanctions',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sanctions',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Sanctions>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'sanctions',
        queries,
      }),
  },
  gradeClaims: {
    create: (
      data: Omit<GradeClaims, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<GradeClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_claims',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<GradeClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_claims',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<GradeClaims, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<GradeClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_claims',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_claims',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<GradeClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_claims',
        queries,
      }),
  },
  claimTypes: {
    create: (
      data: Omit<ClaimTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ClaimTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'claim_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ClaimTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'claim_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ClaimTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ClaimTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'claim_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'claim_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ClaimTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'claim_types',
        queries,
      }),
  },
  gradeDisplayParams: {
    create: (
      data: Omit<GradeDisplayParams, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<GradeDisplayParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_display_params',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<GradeDisplayParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_display_params',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<GradeDisplayParams, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<GradeDisplayParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_display_params',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_display_params',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<GradeDisplayParams>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'grade_display_params',
        queries,
      }),
  },
  apogeeSyncLogs: {
    create: (
      data: Omit<ApogeeSyncLogs, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<ApogeeSyncLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'apogee_sync_logs',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<ApogeeSyncLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'apogee_sync_logs',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<ApogeeSyncLogs, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<ApogeeSyncLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'apogee_sync_logs',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'apogee_sync_logs',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<ApogeeSyncLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'apogee_sync_logs',
        queries,
      }),
  },
  backgroundTasks: {
    create: (
      data: Omit<BackgroundTasks, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<BackgroundTasks>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'background_tasks',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<BackgroundTasks>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'background_tasks',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<BackgroundTasks, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<BackgroundTasks>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'background_tasks',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'background_tasks',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<BackgroundTasks>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'background_tasks',
        queries,
      }),
  },
  announcements: {
    create: (
      data: Omit<Announcements, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Announcements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'announcements',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Announcements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'announcements',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Announcements, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Announcements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'announcements',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'announcements',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Announcements>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'announcements',
        queries,
      }),
  },
  schedules: {
    create: (
      data: Omit<Schedules, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Schedules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'schedules',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Schedules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'schedules',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Schedules, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Schedules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'schedules',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'schedules',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Schedules>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'schedules',
        queries,
      }),
  },
  documentTypes: {
    create: (
      data: Omit<DocumentTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<DocumentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<DocumentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<DocumentTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<DocumentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<DocumentTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_types',
        queries,
      }),
  },
  requestStatuses: {
    create: (
      data: Omit<RequestStatuses, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<RequestStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'request_statuses',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<RequestStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'request_statuses',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<RequestStatuses, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<RequestStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'request_statuses',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'request_statuses',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<RequestStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'request_statuses',
        queries,
      }),
  },
  documentRequests: {
    create: (
      data: Omit<DocumentRequests, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<DocumentRequests>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_requests',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<DocumentRequests>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_requests',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<DocumentRequests, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<DocumentRequests>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_requests',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_requests',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<DocumentRequests>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'document_requests',
        queries,
      }),
  },
  bacWithdrawalTypes: {
    create: (
      data: Omit<BacWithdrawalTypes, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<BacWithdrawalTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_types',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<BacWithdrawalTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_types',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<BacWithdrawalTypes, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<BacWithdrawalTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_types',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_types',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<BacWithdrawalTypes>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_types',
        queries,
      }),
  },
  bacWithdrawalStatuses: {
    create: (
      data: Omit<BacWithdrawalStatuses, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<BacWithdrawalStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_statuses',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<BacWithdrawalStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_statuses',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<BacWithdrawalStatuses, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<BacWithdrawalStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_statuses',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_statuses',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<BacWithdrawalStatuses>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawal_statuses',
        queries,
      }),
  },
  bacWithdrawals: {
    create: (
      data: Omit<BacWithdrawals, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<BacWithdrawals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawals',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<BacWithdrawals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawals',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<BacWithdrawals, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<BacWithdrawals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawals',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawals',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<BacWithdrawals>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'bac_withdrawals',
        queries,
      }),
  },
  signatories: {
    create: (
      data: Omit<Signatories, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Signatories>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'signatories',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Signatories>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'signatories',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Signatories, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Signatories>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'signatories',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'signatories',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Signatories>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'signatories',
        queries,
      }),
  },
  coordinators: {
    create: (
      data: Omit<Coordinators, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Coordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'coordinators',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Coordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'coordinators',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Coordinators, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Coordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'coordinators',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'coordinators',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Coordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'coordinators',
        queries,
      }),
  },
  etapeCoordinators: {
    create: (
      data: Omit<EtapeCoordinators, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<EtapeCoordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etape_coordinators',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<EtapeCoordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etape_coordinators',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<EtapeCoordinators, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<EtapeCoordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etape_coordinators',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etape_coordinators',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<EtapeCoordinators>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'etape_coordinators',
        queries,
      }),
  },
  supervisors: {
    create: (
      data: Omit<Supervisors, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<Supervisors>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'supervisors',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<Supervisors>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'supervisors',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<Supervisors, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<Supervisors>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'supervisors',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'supervisors',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<Supervisors>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'supervisors',
        queries,
      }),
  },
  generalClaims: {
    create: (
      data: Omit<GeneralClaims, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<GeneralClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'general_claims',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<GeneralClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'general_claims',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<GeneralClaims, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<GeneralClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'general_claims',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'general_claims',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<GeneralClaims>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'general_claims',
        queries,
      }),
  },
  auditLogs: {
    create: (
      data: Omit<AuditLogs, keyof Models.Row>,
      options?: { rowId?: string; permissions?: string[] },
    ) =>
      tablesDB.createRow<AuditLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'audit_logs',
        rowId: options?.rowId ?? ID.unique(),
        data,
        permissions: [
          Permission.write(Role.user(data.createdBy)),
          Permission.read(Role.user(data.createdBy)),
          Permission.update(Role.user(data.createdBy)),
          Permission.delete(Role.user(data.createdBy)),
        ],
      }),
    get: (id: string) =>
      tablesDB.getRow<AuditLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'audit_logs',
        rowId: id,
      }),
    update: (
      id: string,
      data: Partial<Omit<AuditLogs, keyof Models.Row>>,
      options?: { permissions?: string[] },
    ) =>
      tablesDB.updateRow<AuditLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'audit_logs',
        rowId: id,
        data,
        ...(options?.permissions ? { permissions: options.permissions } : {}),
      }),
    delete: (id: string) =>
      tablesDB.deleteRow({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'audit_logs',
        rowId: id,
      }),
    list: (queries?: string[]) =>
      tablesDB.listRows<AuditLogs>({
        databaseId: process.env.APPWRITE_DB_ID!,
        tableId: 'audit_logs',
        queries,
      }),
  },
}
